"""Snapshot reports and detached Ed25519 integrity signatures."""
import base64,csv,hashlib,io,json,os,zipfile
from datetime import datetime,timezone,date
from pathlib import Path
from xml.sax.saxutils import escape
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from benchmark_catalog import applies
from analysis import summarize

def signing_key(vault,directory):
    external=os.getenv('AEGIS_SIGNING_KEY')
    if external:return Ed25519PrivateKey.from_private_bytes(base64.b64decode(external,validate=True))
    if os.getenv('AEGIS_PRODUCTION')=='1':raise ValueError('Production requires AEGIS_SIGNING_KEY from an approved key store.')
    path=Path(directory)/'report-signing.key'
    if path.exists():return Ed25519PrivateKey.from_private_bytes(vault.open(path.read_bytes(),'report-signing-key'))
    key=Ed25519PrivateKey.generate();raw=key.private_bytes(serialization.Encoding.Raw,serialization.PrivateFormat.Raw,serialization.NoEncryption())
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(vault.seal(raw,'report-signing-key'))
    return key

def exception_text(a,row):
    matches=[e for e in a['exceptions'] if e['asset']==row['asset'] and e['rule']==row['rule'] and e['baselineId']==row['baselineId']]
    return '; '.join(('Expired' if date.fromisoformat(e['expiry'])<date.today() else 'Approved')+' until '+e['expiry']+' ['+e['approval']+']: '+e['justification'] for e in matches)

def csv_report(a,run):
    output=io.StringIO(newline='');writer=csv.writer(output)
    writer.writerow(['Asset','Baseline and version','Rule','Expected setting','Observed setting','Status','Evidence','Validation','Reviewer note','Exception at export','Severity','Remediation','Framework mapping','Retest change','Previous status','Previous observed','Evidence content changed','Baseline source','Source document','Baseline SHA256','Evidence firmware','Version provenance','Category','XML evidence path'])
    def safe(v):
        value=str(v or '')
        if value.lstrip().startswith(('=','+','-','@')) or value.startswith(('\t','\r')):value="'"+value
        return value
    for r in run['rows']:
        evidence=r['evidence']+'; lines '+','.join(map(str,r.get('checkEvidence',{}).get('lines',[])))+'; '+r.get('checkEvidence',{}).get('reason','')
        writer.writerow([safe(v) for v in [r['asset'],r['baseline']+' v'+r['version'],r['rule'],r['expected'],r['observed'],r['status'],evidence,r['review'],r['note'],exception_text(a,r),r.get('severity'),r.get('remediation'),r.get('mapping'),r.get('change',{}).get('kind'),r.get('change',{}).get('previousStatus'),r.get('change',{}).get('previousObserved'),str(r.get('change',{}).get('evidenceChanged','')),r.get('baselineSource'),r.get('reference'),r.get('baselineHash'),r.get('firmware'),r.get('versionSource','Unknown'),r.get('category','General'),r.get('checkEvidence',{}).get('path','')]])
    return ('\ufeff'+output.getvalue()).encode('utf-8')

def pdf_report(a,run):
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
    from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import landscape,A4
    styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='Cell',fontName='Helvetica',fontSize=8,leading=10,wordWrap='CJK'));styles.add(ParagraphStyle(name='Label',fontName='Helvetica-Bold',fontSize=9,leading=12,textColor=colors.HexColor('#315983')))
    def p(text,style='Cell'):return Paragraph(escape(str(text)).replace('\n','<br/>'),styles[style])
    result=io.BytesIO();doc=SimpleDocTemplate(result,pagesize=landscape(A4),rightMargin=32,leftMargin=32,topMargin=36,bottomMargin=36,title='Aegis OT assessment report',author='Aegis OT')
    pending=sum(r['review']=='Pending' for r in run['rows']);evaluated=[r for r in run['rows'] if r['status'] in ['Pass','Fail']];passes=sum(r['status']=='Pass' for r in evaluated)
    story=[p('AEGIS OT | CONFIGURATION ASSURANCE','Label'),Spacer(1,10),p(a['name'],'Title'),p(a['id']+' | '+a['site'],'Normal'),Spacer(1,10),p('Run '+run['id']+' | '+run['time']+' | '+run['type'],'Normal'),Spacer(1,12),p('DRAFT - '+str(pending)+' results await validation' if pending else 'Validation recorded - review outstanding evidence requests','Label'),Spacer(1,12),p(f'{passes} passing / {len(evaluated)} evaluated checks. {len(run["rows"])-len(evaluated)} checks are manual, unknown, or not applicable.','Normal'),Spacer(1,8),p('This report records configuration evidence, not proof of operational effectiveness. Exceptions are reported as of export time and never change technical results.','Normal'),Spacer(1,18)]
    metrics=summarize(run['rows'])
    story.append(p('Assessment coverage: '+(str(metrics['coverage'])+'%' if metrics['coverage'] is not None else 'Not assessed')+' | Conclusive '+str(metrics['evaluated'])+' of '+str(metrics['applicable'])+' applicable checks.','Normal'))
    story.append(Spacer(1,12))
    story.append(p('Category summary','Heading2'))
    for category in sorted({r.get('category','General') for r in run['rows']}):
        m=summarize([r for r in run['rows'] if r.get('category','General')==category])
        story.append(p(category+' | Compliance '+(str(m['compliance'])+'%' if m['compliance'] is not None else 'Not assessed')+' | Coverage '+(str(m['coverage'])+'%' if m['coverage'] is not None else 'Not assessed')+' | Failures '+str(m['counts']['Fail'])))
    story.append(Spacer(1,12))
    header=['Asset','Baseline / version','Rule','Expected','Observed','Status','Evidence']
    data=[[p(h,'Label') for h in header]]
    for r in run['rows']:
        line=r.get('checkEvidence',{}).get('lines',[])
        ev=('Evidence '+str(r.get('evidenceId') or 'legacy reference'))+('\nLines '+','.join(map(str,line)) if line else '')
        data.append([p(v) for v in [r['asset'],r['baseline']+'\nv'+r['version'],r['rule']+'\n'+r['title'],r['expected'],r['observed'],r['status'],ev]])
    table=Table(data,colWidths=[75,130,128,90,115,80,159],repeatRows=1,hAlign='LEFT',splitInRow=1)
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eaf0f8')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#dce4ef'))]))
    story+=[table,PageBreak(),p('Evidence and review detail','Title')]
    for r in run['rows']:
        detail=[Spacer(1,10),p(r['asset']+' / '+r['rule']+' / '+r['status'],'Heading3'),p('Baseline: '+r['baseline']+' v'+r['version']),p('Evidence: '+r['evidence']),p('Analysis: '+r.get('checkEvidence',{}).get('reason','Explicit baseline comparison')),p('Framework mapping: '+r.get('mapping','')),p('Review: '+r['review']+' | '+r.get('note','')),p('Recommendation: '+r.get('remediation','Auditor to define the appropriate corrective action.'))]
        if r.get('reference'):detail.append(p('Source: '+r['reference']))
        if r.get('firmware'):detail.append(p('OS release: '+r['firmware']+' | Version provenance: '+r.get('versionSource','Unknown')))
        if r.get('checkEvidence',{}).get('path'):detail.append(p('XML evidence path: '+r['checkEvidence']['path']))
        if r.get('change'):detail.append(p('Retest: '+r['change']['kind']+' | Previous: '+str(r['change']['previousStatus'])+' | Configuration content '+('changed' if r['change']['evidenceChanged'] else 'unchanged')))
        exc=exception_text(a,r)
        if exc:detail.append(p('Exception at export: '+exc))
        story.append(KeepTogether(detail))
    story+=[Spacer(1,18),p('Signature verification','Heading2'),p('This PDF is included in a signed export package. The detached Ed25519 signature covers manifest.json, which contains the report SHA-256 digest. Verify using verify_report.py and a separately trusted signing-key fingerprint. This is not an embedded PDF certificate signature or a trusted timestamp.')]
    def footer(canvas,doc):
        canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#62738b'));canvas.drawString(32,20,'Aegis OT | '+a['id']);canvas.drawRightString(810,20,'Page '+str(doc.page))
    doc.build(story,onFirstPage=footer,onLaterPages=footer);return result.getvalue()

def export_bundle(a,run,fmt,vault,directory,actor,audit_head):
    if fmt not in ['csv','pdf']:raise ValueError('Choose CSV or PDF.')
    data=csv_report(a,run) if fmt=='csv' else pdf_report(a,run)
    key=signing_key(vault,directory);public=key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
    fp=hashlib.sha256(public).hexdigest();name='report.'+fmt
    manifest=dict(schema='aegis-signed-export-v1',assessment=a['id'],run=run['id'],exportedAt=datetime.now(timezone.utc).isoformat(),exportedBy=actor,rows=len(run['rows']),files={name:hashlib.sha256(data).hexdigest()},signingKeySHA256=fp,auditHead=audit_head,exceptionScope='current approvals at export time',signature='Ed25519 detached; no trusted timestamp')
    raw=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode();zipdata=io.BytesIO()
    with zipfile.ZipFile(zipdata,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr(name,data);z.writestr('manifest.json',raw);z.writestr('manifest.sig',base64.b64encode(key.sign(raw)));z.writestr('signer-public.pem',public)
        z.writestr('VERIFY.txt','Verify with: python verify_report.py EXPORT.zip --trusted-fingerprint FINGERPRINT\nObtain the fingerprint from your administrator over a trusted channel.\nIncluded-key fingerprint: '+fp)
    return zipdata.getvalue(),fp
