"""Verify detached signed exports against an independently trusted public-key fingerprint."""
import argparse,base64,hashlib,hmac,json,zipfile
from cryptography.hazmat.primitives.serialization import load_pem_public_key
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
def verify(path,fingerprint):
    with zipfile.ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist())>100*1024*1024:raise ValueError('Export exceeds verification size limit.')
        if len(z.namelist())!=len(set(z.namelist())):raise ValueError('Duplicate ZIP members.')
        public=z.read('signer-public.pem');actual=hashlib.sha256(public).hexdigest()
        if not hmac.compare_digest(actual,fingerprint.lower()):raise ValueError('Signing key is not trusted.')
        key=load_pem_public_key(public)
        if not isinstance(key,Ed25519PublicKey):raise ValueError('Unsupported signing key.')
        raw=z.read('manifest.json');key.verify(base64.b64decode(z.read('manifest.sig'),validate=True),raw);manifest=json.loads(raw)
        if manifest['signingKeySHA256']!=actual or manifest['schema']!='aegis-signed-export-v1':raise ValueError('Invalid manifest.')
        for name,digest in manifest['files'].items():
            if name not in ['report.csv','report.pdf']:raise ValueError('Unexpected report member.')
            if not hmac.compare_digest(hashlib.sha256(z.read(name)).hexdigest(),digest):raise ValueError('Report content was modified.')
        if not manifest['files']:raise ValueError('No report in manifest.')
        return manifest
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('export');p.add_argument('--trusted-fingerprint',required=True);args=p.parse_args()
    result=verify(args.export,args.trusted_fingerprint);print('Verified report signature and content:',result['assessment'],result['run'])
