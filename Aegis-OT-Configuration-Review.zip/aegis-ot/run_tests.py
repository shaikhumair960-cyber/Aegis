"""Run regression tests against temporary data and a disposable encryption key."""
import base64,os,secrets,unittest
from pathlib import Path
if __name__=='__main__':
    os.environ['AEGIS_MASTER_KEY']=base64.b64encode(secrets.token_bytes(32)).decode()
    os.environ.pop('AEGIS_PRODUCTION',None)
    os.environ['AEGIS_REQUIRE_LOGIN']='1'
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover(str(Path(__file__).parent),pattern='test_*.py'))
    raise SystemExit(0 if result.wasSuccessful() else 1)
