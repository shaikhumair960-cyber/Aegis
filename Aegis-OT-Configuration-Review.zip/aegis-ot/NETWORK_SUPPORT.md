# Network adapter contract

Each adapter implements `parse(text, platform, declared_version)` and produces allowlisted settings, parser version, release provenance, warnings and source locations. `evaluate` checks rule identity, platform, policy expectation, parser and asset version before returning a result. It rejects unsupported policy modifications instead of silently reusing an evaluator. Raw originals remain encrypted evidence; extracted findings omit unrelated secrets.

## Sources reviewed 2026-09-24

- Cisco: [IOS XE Software Hardening Guide](https://sec.cloudapps.cisco.com/security/center/resources/IOS_XE_hardening). Aegis selects management-service checks; the timeout threshold is local policy, not a copied benchmark requirement.
- HPE Aruba: [AOS-S access security features](https://arubanetworking.hpe.com/techdocs/AOS-S/16.10/ASG/WC/content/common%20files/acc-sec-fea.htm). AOS-S syntax only; AOS-CX and Comware need separate adapters.
- Palo Alto: [PAN-OS 11.2 configuration command hierarchy](https://docs.paloaltonetworks.com/ngfw/pan-os-cli-quick-start/cli-command-hierarchy/pan-os-11-2-configure-cli-command-hierarchy). Only standalone management service flags are evaluated, not dataplane management profiles or Panorama inheritance.
- Juniper: [SSH system services reference](https://www.juniper.net/documentation/us/en/software/junos/cli-reference/topics/ref/statement/ssh-edit-system.html). Set-format SSH policy evidence is evaluated without assuming omitted defaults. Explicit Telnet is flagged; absent Telnet requires review.
- Fortinet: see `fortinet-source.json` for the downloaded guide revision, digest and reviewed subset.

## Result meanings

- **Pass:** explicit evidence meets this selected rule, within its supported scope.
- **Fail:** explicit evidence violates the selected rule.
- **Unable to assess:** omitted, ambiguous, conflicting or unsupported evidence.
- **Manual review:** the requirement or effective configuration needs human evidence.
- **Not applicable:** a recorded applicability or precedence decision excludes the rule.

Compliance excludes unknown/manual checks; coverage exposes those gaps separately. Neither metric asserts that the device is secure or fully benchmark-compliant. Approved exceptions preserve the technical result.

## Extending coverage

Add a distinct platform identity, supported version/format contract, original or licensed requirements, parser, evaluator and representative redacted test fixtures. Test positive/negative cases, missing defaults, context boundaries, malformed input, version mismatch, secret redaction, inheritance and retest changes. Add product directory entries only alongside clear parser availability. Increment the parser and rule-pack versions when semantics change. Do not infer a vendor parser from shared command spellings.

## Validation in this release

Synthetic fixtures exercise preview, explicit confirmation, comparison, category metadata, signed CSV export and retest for all four new families. Parser tests cover banner/certificate isolation, nested Cisco commands, missing VTY settings, duplicate values, XML entities and malformed input, Junos inheritance/deactivation, cross-platform evidence, version mismatch and secret redaction. Real production configurations have not been supplied for acceptance testing.
