"""Local account administration. No SSO or MFA."""
import argparse,getpass,hashlib,re,secrets
import server
def main():
    parser=argparse.ArgumentParser(description='Aegis local account administration')
    sub=parser.add_subparsers(dest='command',required=True)
    create=sub.add_parser('create-user');create.add_argument('name');create.add_argument('--role',choices=['admin','auditor','reviewer'],required=True)
    change=sub.add_parser('change-password');change.add_argument('name')
    disable=sub.add_parser('disable-user');disable.add_argument('name')
    sub.add_parser('list-users');sub.add_parser('verify-audit');sub.add_parser('signer-fingerprint')
    args=parser.parse_args();server.init()
    if args.command=='verify-audit':print(server.verify_audit());return
    if args.command=='signer-fingerprint':
        from reports import signing_key
        from cryptography.hazmat.primitives import serialization
        key=signing_key(server.vault(),server.DB.parent)
        print(hashlib.sha256(key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)).hexdigest());return
    with server.database() as c:
        if args.command=='list-users':
            for row in c.execute('SELECT name,role,active FROM users'):print(*row)
            return
        if not re.fullmatch(r'[A-Za-z0-9._@-]{3,80}',args.name):raise SystemExit('Use 3–80 letters, numbers, dot, underscore, @ or hyphen.')
        if args.command=='disable-user':
            row=c.execute('SELECT role,active FROM users WHERE name=?',(args.name,)).fetchone()
            if not row:raise SystemExit('Unknown account.')
            if row[0]=='admin' and row[1] and c.execute("SELECT count(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]<=1:raise SystemExit('Cannot disable the last active administrator.')
            c.execute('UPDATE users SET active=0 WHERE name=?',(args.name,))
        else:
            password=getpass.getpass('Password (at least 14 characters): ')
            if len(password)<14 or password!=getpass.getpass('Confirm password: '):raise SystemExit('Passwords must match and contain at least 14 characters.')
            salt=secrets.token_hex(16);digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),200000).hex()
            if args.command=='create-user':c.execute('INSERT INTO users (name,role,salt,digest,active) VALUES (?,?,?,?,1)',(args.name,args.role,salt,digest))
            else:
                if not c.execute('SELECT 1 FROM users WHERE name=?',(args.name,)).fetchone():raise SystemExit('Unknown account.')
                c.execute('UPDATE users SET salt=?,digest=? WHERE name=?',(salt,digest,args.name))
    server.audit('',getpass.getuser(),'Account administration',args.command+' '+args.name)
    print('Account updated. Password changes invalidate existing sessions on their next request.')
if __name__=='__main__':main()
