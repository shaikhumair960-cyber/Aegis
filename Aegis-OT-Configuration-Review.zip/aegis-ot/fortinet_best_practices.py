"""Reviewed subset of the downloaded FortiOS 7.4 Best Practices guide.

Thresholds, exclusions and human review are explicit; this is not the entire guide.
"""
from fortigate import firmware_error,PARSER_VERSION
PDF='https://fortinetweb.s3.amazonaws.com/docs.fortinet.com/v2/attachments/f07c9167-03f4-11ee-8e6d-fa163e15d75b/FortiOS-7.4-Best_Practices.pdf'
HASH='cd3fdcd208db5ca9de2d5c2b2d10ce97f2637eac0881a6686fb344688412e2ce'
# ID, title, section, setting, expected, severity, PDF page, category
SPECS=[
 ('FGBP-01','Administrator idle timeout','system global','admintimeout','1–9 minutes','Medium',11,'Administration'),
 ('FGBP-02','Nonstandard HTTPS port','system global','admin-sport','Valid port other than 443','Low',11,'Administration'),
 ('FGBP-03','Nonstandard SSH port','system global','admin-ssh-port','Valid port other than 22','Low',11,'Administration'),
 ('FGBP-04','HTTP redirect safeguards','system global','admin-https-redirect','Disabled; otherwise configured redirect host','Medium',12,'Administration'),
 ('FGBP-05','Strong cryptography','system global','strong-crypto','enable','High',39,'Cryptography'),
 ('FGBP-06','Static-key TLS ciphers','system global','ssl-static-key-ciphers','disable','High',39,'Cryptography'),
 ('FGBP-07','DH parameter size','system global','dh-params','8192','Medium',39,'Cryptography'),
 ('FGBP-08','Cleartext management','interfaces','allowaccess','No HTTP/Telnet in IPv4 or IPv6 access','High',12,'Administration'),
]
MANUAL=[
 ('FGBP-09','Management network isolation',10,'Network','Verify management paths and exposure.'),
 ('FGBP-10','Administrator privileges and authentication',11,'Authentication','Review accounts, privilege scope and authentication evidence.'),
 ('FGBP-11','Trusted management certificate',11,'Cryptography','Validate identity, trust and expiry.'),
 ('FGBP-12','Time synchronization',8,'Operations','Verify clock accuracy and synchronization.'),
 ('FGBP-13','Logging and reporting',16,'Logging','Verify destinations, retention and received events.'),
 ('FGBP-14','Physical access safeguards',37,'Operations','Review physical security and conditional USB safeguards.'),
 ('FGBP-15','Firmware and vulnerability management',38,'Operations','Check support, advisories and approved upgrades.'),
 ('FGBP-16','Configuration backup',41,'Operations','Verify secure backups and recovery testing.'),
]

def catalog_entry():
    rules=[]
    for rid,title,section,setting,expected,severity,page,category in SPECS:
        rules.append(dict(id=rid,title=title,key='fortinet.'+setting,expected=expected,mode='automated',applicable=True,mapping='Fortinet Best Practices p. '+str(page),engine='fortinet-best-practices',severity=severity,remediation='Apply the documented setting after compatibility and change review: '+expected+'.',reference=PDF+'#page='+str(page),category=category))
    for rid,title,page,category,recommendation in MANUAL:
        rules.append(dict(id=rid,title=title,key='fortinet.manual.'+rid,expected='Auditor evidence required',mode='manual',applicable=True,mapping='Fortinet Best Practices p. '+str(page),severity='Unrated',remediation=recommendation,reference=PDF+'#page='+str(page),category=category))
    return dict(id='fortinet-bp74-reviewed-v2',name='Fortinet FortiOS 7.4 Best Practices — reviewed subset',source='Vendor hardening guide',product='Firewall',vendor='Fortinet',family='FortiGate',os='FortiOS',productVersion='7.4.x',version='guide-2026-06-24/checks-2.0',profile='8 automated + 8 manual requirements',installed=True,license='Aegis implementation of a documented subset, not Fortinet certification. Official PDF linked; numeric preferences evaluated explicitly.',url=PDF,hash=HASH,rules=rules)

def evaluate(config,rule,asset):
    reason=firmware_error(config,asset)
    if reason:return 'Unable to assess',reason,dict(reason=reason,parser=PARSER_VERSION,lines=[])
    spec=next((s for s in SPECS if s[0]==rule['id']),None)
    if not spec or rule['expected']!=spec[4] or rule['key']!='fortinet.'+spec[3]:return 'Manual review','Modified requirement needs a validated evaluator.',{}
    _,_,section,setting,_,_,page,_=spec
    data=config.get('bestPracticeEvidence',{})
    records=data.get(section,{}) if section!='interfaces' else {};record=records.get(setting)
    detail=dict(parser=PARSER_VERSION,lines=[],reason='Fortinet Best Practices, PDF page '+str(page)+'. Explicit export settings only; omitted defaults are unknown.',reference=rule['reference'],firmware=config['firmware'])
    def result(status,observed,items):
        detail['lines']=[r['line'] for r in items];detail['snippets']=[dict(line=r['line'],context=r['context'],setting=r['setting'],value=' '.join(r['values'] or [])) for r in items]
        return status,observed,detail
    if section=='interfaces':
        rows=data.get('interfaces',[])
        if not rows:return result('Unable to assess','No interface access settings found.',[])
        insecure=[r for r in rows if r['values'] and {'http','telnet'}&set(r['values'])]
        if insecure:return result('Fail','Cleartext access in: '+', '.join(r['context'] for r in insecure),insecure)
        if data.get('vdom'):return result('Manual review','Review VDOM interface coverage.',[r for r in rows if r['values'] is not None])
        if any(r['values'] is None for r in rows):return result('Unable to assess','IPv4 or IPv6 access setting omitted; supply full configuration.',[r for r in rows if r['values'] is not None])
        return result('Pass','No explicit HTTP/Telnet access.',rows)
    if not record or record['values'] is None:return result('Unable to assess','Setting not explicit in export.',[])
    values=record['values'];observed=' '.join(values);items=[record]
    if setting=='admintimeout':ok=len(values)==1 and values[0].isdigit() and 1<=int(values[0])<10
    elif setting in ['admin-sport','admin-ssh-port']:ok=len(values)==1 and values[0].isdigit() and 1<=int(values[0])<=65535 and int(values[0])!=(443 if setting=='admin-sport' else 22)
    elif setting=='admin-https-redirect':
        host=records.get('admin-host')
        if values==['disable']:ok=True
        elif values==['enable'] and host and host['values'] and ''.join(host['values']).strip():
            return result('Manual review','Redirect enabled with host '+''.join(host['values'])+'; verify approved exception and hostname.',items+[host])
        elif values==['enable'] and not host:return result('Unable to assess','Redirect enabled; redirect host omitted.',items)
        else:ok=False
    else:ok=values==[spec[4]]
    return result('Pass' if ok else 'Fail',observed,items)
