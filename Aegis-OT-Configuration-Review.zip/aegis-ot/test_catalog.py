import base64, copy, json, tempfile, unittest
from pathlib import Path
import server
from benchmark_catalog import applies, version_matches, REFERENCES, PRODUCTS

class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.old=server.DB;server.DB=Path(self.tmp.name)/'data'/'audit.db';server.init()
        self.a=server.seed(); self.a['assets']=[dict(id='forti',name='Forti',product='Firewall',group='Zone A',vendor='Fortinet',family='FortiGate',version='7.4.5',criticality='High'),dict(id='palo',name='Palo',product='Firewall',group='Zone A',vendor='Palo Alto Networks',family='PA-Series / VM-Series',version='11.1.2',criticality='High')];self.a['baselines']=[];server.save(self.a)
    def tearDown(self):server.DB=self.old;self.tmp.cleanup()
    def process(self,action,**kwargs):
        self.a=server.process(self.a,action,kwargs,{'name':'admin','role':'admin'});return self.a
    def test_reference_is_browsable_not_executable(self):
        self.assertTrue(any(x['family']=='FortiGate' for x in REFERENCES))
        self.assertTrue(any(x['vendor']=='HPE / Aruba (HP)' for x in PRODUCTS))
        with self.assertRaises(ValueError):self.process('catalog',entry=REFERENCES[0]['id'],group='Zone A',license=True)
    def test_firmware_boundaries_and_vendor_matching(self):
        self.assertTrue(version_matches('7.4.x','7.4.5'))
        self.assertTrue(version_matches('17.x','17.9.4'))
        self.assertFalse(version_matches('7.4.x','7.40.1'))
        self.assertFalse(version_matches('7.4.5','7.4.6'))
        b=dict(group='Zone A',devices='Firewall',vendor='Fortinet',family='FortiGate',productVersion='7.4.x')
        self.assertTrue(applies(b,self.a['assets'][0]));self.assertFalse(applies(b,self.a['assets'][1]))
        missing=dict(self.a['assets'][0]);missing.pop('vendor');self.assertFalse(applies(b,missing))
    def test_import_activate_reuse_and_correct_asset_results(self):
        csv=b'id,title,key,expected\nF-1,Example check,setting,true\n'
        d=dict(filename='authorized.csv',data=base64.b64encode(csv).decode(),name='Authorized test',version='1.0',approval='QA',date='2026-01-01',devices='Firewall',group='Zone A',vendor='Fortinet',family='FortiGate',productVersion='7.4.x',source='CIS',profile='Auditor-verified profile',rights=True)
        self.process('upload_baseline',**d);b=self.a['baselines'][0]
        self.assertFalse(any(e['id']=='import-'+b['id'] for e in server.catalog_entries()))
        b['rules'][0]['mode']='automated';self.process('rules',baseline=b['id'],rules=b['rules']);self.process('activate',baseline=b['id'],confirmed=True)
        entry=next(e for e in server.catalog_entries() if e['id']=='import-'+b['id']);self.assertEqual(entry['profile'],d['profile']);self.assertTrue(entry['installed'])
        self.process('catalog',entry=entry['id'],group='Zone A',license=True)
        self.process('run');self.assertEqual({r['assetId'] for r in self.a['runs'][-1]['rows']},{'forti'})
        self.assertEqual(self.a['runs'][-1]['baselines'][0]['productVersion'],'7.4.x')
    def test_product_details_update_preserves_identity_and_history(self):
        asset=dict(self.a['assets'][0]);self.process('update_asset',asset='forti',**{k:v for k,v in asset.items() if k!='id'},os='FortiOS')
        self.assertEqual(self.a['assets'][0]['id'],'forti');self.assertEqual(self.a['assets'][0]['os'],'FortiOS')
    def test_unrelated_vendors_do_not_conflict(self):
        for asset,expected in zip(self.a['assets'],['true','false']):
            b=server.baseline();b.update(group=asset['group'],vendor=asset['vendor'],family=asset['family'],productVersion=asset['version']);b['rules']=[server.rule('A','Example','same_key',expected)];self.a['baselines'].append(b)
        self.assertEqual(server.conflicts(self.a),[])
    def test_unauthorized_cis_import_rejected(self):
        with self.assertRaises(ValueError):self.process('upload_baseline',filename='a.csv',data=base64.b64encode(b'title\nExample test\n').decode(),name='Test',version='1',approval='A',date='2026-01-01',devices='Firewall',group='Zone A',source='CIS')

if __name__=='__main__':unittest.main(verbosity=2)
