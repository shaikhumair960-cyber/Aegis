"""Guided native review: inspect first, then explicitly confirm a versioned pack."""
import hashlib,json,re
from datetime import date
from fortigate import parse
from fortinet_best_practices import catalog_entry,evaluate
from analysis import summarize
import network_devices as network

def inspect(core,d):
    filename,ext,raw=core.filedata(d,['.conf','.cfg','.txt','.xml','.set'])
    try:text=raw.decode('utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
    except UnicodeError:raise ValueError('Use an unencrypted UTF-8 or BOM-marked UTF-16 FortiGate text export.')
    platform=d.get('platform','fortigate')
    core.require('\x00' not in text,'Binary or encrypted files cannot be evaluated.')
    if platform=='fortigate':
        core.require(not text.lstrip().startswith('<'),'FortiGate requires a plain-text export, not XML.')
        parsed=parse(text);version=parsed.get('firmware') or ''
        core.require(re.fullmatch(r'7\.4\.\d+',version),'A FortiOS 7.4.x version header is required. Upload a native backup containing #config-version.')
        entry=catalog_entry();evaluator=evaluate
    else:
        parsed=network.parse(text,platform,str(d.get('osVersion','')).strip());version=parsed['firmware']
        entry=network.entry(platform,version);evaluator=network.evaluate
    rows=[]
    asset=dict(version=version,vendor=entry['vendor'],family=entry['family'])
    for rule in entry['rules']:
        status,observed,detail=evaluator(parsed,rule,asset) if rule['mode']=='automated' else ('Manual review','Auditor evidence required',{})
        rows.append(dict(rule=rule['id'],title=rule['title'],expected=rule['expected'],observed=observed,status=status,category=rule['category'],reference=rule['reference']))
    digest=hashlib.sha256(raw).hexdigest()
    public=dict(filename=filename,hash=digest,firmware=version,parser=parsed['parser'],baseline={k:entry[k] for k in ['id','name','version','profile','url','hash']},summary=summarize(rows),rows=rows,warnings=parsed['warnings'])
    public.update(platform=platform,versionSource=parsed.get('versionSource','Export header'),source=entry['source'])
    public['previewToken']=hashlib.sha256(json.dumps([digest,platform,version,entry['hash']],ensure_ascii=True).encode()).hexdigest()
    return public,parsed,entry,raw

def create_review(core,d,user):
    public,parsed,entry,raw=inspect(core,d)
    core.require(d.get('confirmed') is True,'Review the requirements and confirm the selected baseline before running.')
    core.require(d.get('previewHash')==public['hash'],'The file changed after preview. Preview it again before running.')
    if public['platform']!='fortigate':core.require(d.get('previewToken')==public['previewToken'],'Device details or baseline changed. Preview again before confirmation.')
    name=str(d.get('device','')).strip();reference=str(d.get('auditorReference','')).strip()
    core.require(0<len(name)<=120 and 0<len(reference)<=240,'Enter a device name (up to 120 characters) and auditor reference (up to 240 characters).')
    aid='OT-'+core.uid()[:6].upper();assetid=core.uid();baselineid=core.uid()
    baseline=dict(id=baselineid,name=entry['name'],version=entry['version'],source=entry['source'],devices=entry['product'],vendor=entry['vendor'],family=entry['family'],os=entry['os'],productVersion=entry['productVersion'],profile=entry['profile'],group='Configuration review',approval=reference,date=date.today().isoformat(),confirmed=True,active=True,confirmedBy=user['name'],confirmedAt=core.now(),filename='Reviewed catalog pack',hash=entry['hash'],rules=entry['rules'])
    a=dict(id=aid,name=name+' configuration review',site='Offline configuration review',owner=user['name'],created=core.now(),members=[user['name']],assets=[dict(id=assetid,name=name,group='Configuration review',product=entry['product'],vendor=entry['vendor'],family=entry['family'],os=entry['os'],version=public['firmware'],criticality='Unspecified')],baselines=[baseline],configs={},runs=[],exceptions=[],precedence={},events=[dict(time=core.now(),actor=user['name'],action='Confirmed guided baseline review: '+reference)])
    values=parsed.pop('values')
    a['configs'][assetid]=dict(filename=public['filename'],hash=public['hash'],time=core.now(),collector=user['name'],evidenceId=core.retain(aid,public['filename'],raw,user),values=values,**parsed)
    return core.process(a,'run',{},user)
