import unittest
from pathlib import Path
from fortigate import parse
from fortinet_best_practices import catalog_entry,evaluate,HASH
FIXTURE=(Path(__file__).parent/'samples'/'fortinet-best-practices-7.4.5.conf').read_text()

class OfficialGuideTests(unittest.TestCase):
    def results(self,text,version='7.4'):
        c=parse(text)
        return {r['id']:evaluate(c,r,dict(version=version)) for r in catalog_entry()['rules'] if r['mode']=='automated'}
    def test_complete_export_family_version(self):
        rows=self.results(FIXTURE)
        self.assertEqual(sum(r[0]=='Pass' for r in rows.values()),7)
        self.assertEqual(rows['FGBP-08'][0],'Fail')
        self.assertTrue(all(r[2]['firmware']=='7.4.5' for r in rows.values()))
    def test_guide_threshold_and_changed_configuration(self):
        self.assertEqual(self.results(FIXTURE.replace('admintimeout 5','admintimeout 10'))['FGBP-01'][0],'Fail')
        self.assertEqual(self.results(FIXTURE.replace('https ssh telnet','https ssh'))['FGBP-08'][0],'Pass')
    def test_ipv6_is_also_checked(self):
        text=FIXTURE.replace('https ssh telnet','https ssh').replace('ip6-allowaccess ""','ip6-allowaccess telnet')
        self.assertEqual(self.results(text)['FGBP-08'][0],'Fail')
    def test_missing_settings_stay_unknown(self):
        self.assertEqual(self.results(FIXTURE.replace('    set strong-crypto enable\n',''))['FGBP-05'][0],'Unable to assess')
    def test_mismatched_and_missing_firmware(self):
        self.assertTrue(all(r[0]=='Unable to assess' for r in self.results(FIXTURE,'7.4.6').values()))
        self.assertTrue(all(r[0]=='Unable to assess' for r in self.results('\n'.join(FIXTURE.splitlines()[1:])).values()))
    def test_snapshot_provenance_and_manual_scope(self):
        entry=catalog_entry();self.assertEqual(entry['hash'],HASH)
        self.assertEqual(sum(r['mode']=='manual' for r in entry['rules']),8)
        self.assertTrue(all('#page=' in r['reference'] for r in entry['rules']))

if __name__=='__main__':unittest.main()
