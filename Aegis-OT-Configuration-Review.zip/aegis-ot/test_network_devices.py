import base64,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import network_devices as net
import config_review,server
from webapp import create_app

ROOT=Path(__file__).parent
VERSIONS={'cisco-iosxe':'17.9','aruba-aos':'WC.16.11.0013','paloalto-panos':'11.2.0','juniper-junos':'24.2R1.10'}
def fixture(platform):return (ROOT/'samples'/net.PLATFORMS[platform]['sample']).read_text(encoding='utf-8')

class NativeNetworkTests(unittest.TestCase):
 def test_expected_results_for_all_four_families(self):
  for platform in net.PLATFORMS:
   with self.subTest(platform=platform):
    parsed=net.parse(fixture(platform),platform,VERSIONS[platform]);e=net.entry(platform)
    asset=dict(version=VERSIONS[platform],vendor=e['vendor'],family=e['family'])
    statuses=[net.evaluate(parsed,r,asset)[0] for r in e['rules'] if r['mode']=='automated']
    self.assertEqual(statuses.count('Fail'),1);self.assertEqual(statuses.count('Pass'),len(net.SPECS[platform])-1)
 def test_absence_never_becomes_pass(self):
  for platform,text in [('cisco-iosxe','version 17.9\nhostname X\nend'),('aruba-aos','; Aruba Configuration Editor\nhostname X'),('paloalto-panos','<config><devices><entry><deviceconfig><system/></deviceconfig></entry></devices></config>'),('juniper-junos','set system host-name X')]:
   with self.subTest(platform=platform):self.assertEqual({r['status'] for r in net.parse(text,platform,VERSIONS[platform])['networkChecks'].values()},{'Unable to assess'})
 def test_cisco_banner_interface_and_certificate_are_not_global_settings(self):
  text='version 17.9\nbanner motd ^C\nip ssh version 2\nno ip http server\n^C\ninterface Gi1\n ip ssh version 2\ncrypto pki certificate chain TEST\nno ip http server\nquit\nend'
  p=net.parse(text,'cisco-iosxe','17.9');self.assertEqual(p['networkChecks']['ssh2']['status'],'Unable to assess');self.assertEqual(p['networkChecks']['http']['status'],'Unable to assess')
 def test_cisco_missing_vty_timeout_and_duplicates(self):
  text=fixture('cisco-iosxe').replace(' exec-timeout 5 0','',1)+'\n'
  self.assertEqual(net.parse(text,'cisco-iosxe','17.9')['networkChecks']['timeout']['status'],'Unable to assess')
  text=fixture('cisco-iosxe').replace('ip ssh version 2','ip ssh version 2\nip ssh version 1')
  self.assertEqual(net.parse(text,'cisco-iosxe','17.9')['networkChecks']['ssh2']['status'],'Unable to assess')
 def test_wrong_format_and_release_rejected(self):
  for platform in net.PLATFORMS:
   with self.subTest(platform=platform):
    with self.assertRaises(ValueError):net.parse('not a native export',platform,VERSIONS[platform])
    with self.assertRaises(ValueError):net.parse(fixture(platform),platform,'99.1')
  with self.assertRaises(ValueError):net.parse(fixture('cisco-iosxe'),'cisco-iosxe','16.12')
  with self.assertRaises(ValueError):net.parse('version 17.9\nbanner motd ^C\nend','cisco-iosxe','17.9')
 def test_junos_inheritance_and_deactivation_require_manual_review(self):
  for extra in ['set apply-groups production','deactivate system services ssh','set groups production system services telnet']:
   p=net.parse(fixture('juniper-junos')+'\n'+extra,'juniper-junos','24.2R1.10')
   self.assertEqual({o['status'] for o in p['networkChecks'].values()},{'Manual review'})
 def test_xml_rejects_entities_templates_malformed_and_duplicate_settings(self):
  for text in ['<!DOCTYPE config [<!ENTITY x "yes">]>'+fixture('paloalto-panos'),'<config>',fixture('paloalto-panos').replace('<deviceconfig>','<template/><deviceconfig>')]:
   with self.assertRaises(ValueError):net.parse(text,'paloalto-panos','11.2')
  text=fixture('paloalto-panos').replace('<disable-http>yes</disable-http>','<disable-http>yes</disable-http><disable-http>no</disable-http>')
  p=net.parse(text,'paloalto-panos','11.2');self.assertEqual(p['networkChecks']['disable-http']['status'],'Unable to assess');self.assertEqual(p['versionSource'],'Auditor declaration')
 def test_secrets_are_not_in_normalized_evidence(self):
  text=fixture('cisco-iosxe').replace('hostname SAMPLE-CISCO','hostname SAMPLE-CISCO\nusername admin secret 9 DO-NOT-LEAK\nsnmp-server community DO-NOT-LEAK RO')
  self.assertNotIn('DO-NOT-LEAK',json.dumps(net.parse(text,'cisco-iosxe','17.9')))
 def test_modified_policy_and_cross_platform_evidence_cannot_pass(self):
  p=net.parse(fixture('cisco-iosxe'),'cisco-iosxe','17.9');r=net.entry('cisco-iosxe')['rules'][0];asset=dict(version='17.9',vendor='Cisco',family='Catalyst (IOS XE)')
  r['expected']='1';self.assertEqual(net.evaluate(p,r,asset)[0],'Manual review')
  r=net.entry('paloalto-panos')['rules'][0];self.assertEqual(net.evaluate(p,r,asset)[0],'Unable to assess')
 def test_catalog_rejects_unsupported_device_release(self):
  from benchmark_catalog import catalog_matches
  e=net.entry('cisco-iosxe');asset=dict(product='Switch',vendor='Cisco',family='Catalyst (IOS XE)',version='99.1',group='G')
  self.assertFalse(catalog_matches(e,asset));asset['version']='17.9';self.assertTrue(catalog_matches(e,asset))

class NetworkWorkflowTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.old=server.DB;server.DB=Path(self.tmp.name)/'audit.db';server.init()
  self.mode=patch.dict(os.environ,{'AEGIS_REQUIRE_LOGIN':'0','AEGIS_PRODUCTION':'0'});self.mode.start()
  self.client=create_app(server).test_client();self.state=self.client.get('/api/state').json;self.headers={'X-CSRF-Token':self.state['user']['csrf']}
 def tearDown(self):self.mode.stop();server.DB=self.old;self.tmp.cleanup()
 def post(self,path,d):return self.client.post('/api/'+path,json=d,headers=self.headers)
 def payload(self,p,text=None):return dict(platform=p,osVersion=VERSIONS[p],filename=net.PLATFORMS[p]['sample'],data=base64.b64encode((text or fixture(p)).encode()).decode())
 def test_all_families_preview_run_export_and_retest(self):
  for p in net.PLATFORMS:
   with self.subTest(platform=p):
    payload=self.payload(p);preview=self.post('config-preview',payload);self.assertEqual(preview.status_code,200,preview.json)
    d=dict(payload,previewHash=preview.json['hash'],previewToken=preview.json['previewToken'],confirmed=True,device=p,auditorReference='TEST')
    response=self.post('config-review',d);self.assertEqual(response.status_code,200,response.json)
    a=server.load(response.json['id']);run=a['runs'][-1];self.assertEqual(run['analysis']['counts']['Fail'],1);self.assertEqual(run['analysis']['counts']['Manual review'],3)
    self.assertTrue(all(r['category'] and r['baselineHash'] and r['reference'] for r in run['rows']))
    report=self.post('report',dict(assessment=a['id'],run=run['id'],format='csv'));self.assertEqual(report.status_code,200)
    upload=self.post('action',dict(payload,assessment=a['id'],action='config',asset=a['assets'][0]['id']));self.assertEqual(upload.status_code,200,upload.json)
    retest=self.post('action',dict(assessment=a['id'],action='run',retest=True));self.assertEqual(retest.status_code,200,retest.json)
 def test_preview_binds_platform_and_version_and_csrf(self):
  payload=self.payload('paloalto-panos');preview=self.post('config-preview',payload).json
  d=dict(payload,osVersion='10.2',previewHash=preview['hash'],previewToken=preview['previewToken'],confirmed=True,device='X',auditorReference='T')
  self.assertEqual(self.post('config-review',d).status_code,400)
  self.assertEqual(self.client.post('/api/config-review',json=d).status_code,400)
