@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
    if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" server.py
if errorlevel 1 goto failed
exit /b 0
:failed
echo.
echo Setup or startup failed. Review the error above. Python 3.10+ and internet access for dependency installation are required.
pause
exit /b 1
