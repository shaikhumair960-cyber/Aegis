# Aegis OT — Configuration Assurance

## Multi-vendor network review — build 2026.09.24-network-review

Start at **Overview → Review configuration**. Choose the platform, enter the installed OS release, upload evidence, preview the versioned requirements, confirm, and run. Results open on **Summary**, with **Categories** and **Detailed findings** tabs. Category drilldowns retain filters for CSV export. Signed full-run CSV/PDF exports include all findings; PDF reports preserve category summaries and control detail.

| Adapter | Initial OS scope | Export format | Automated / manual rules |
| --- | --- | --- | --- |
| Fortinet FortiGate | FortiOS 7.4.x | Native text backup with firmware header | 8 / 8 |
| Cisco IOS / IOS XE | IOS 15.x; IOS XE 16.x / 17.x | Running configuration text with version and end markers | 5 / 3 |
| Aruba / HP ProCurve | AOS-S 16.10 / 16.11 | Text export with device header and hostname | 4 / 3 |
| Palo Alto Networks | PAN-OS 10.x / 11.x | Standalone device XML configuration | 4 / 3 |
| Juniper Networks | Junos 21.x–24.x | `display set` configuration text | 3 / 3 |

The four new adapters implement **original Aegis management policies**, with syntax references to official documentation. They are not complete vendor benchmarks or CIS implementations. Cisco checks SSH version, exported VTY transport, HTTP management, AAA enablement and a 1–600 second Aegis idle-timeout policy. AOS-S checks explicit management service settings. PAN-OS checks four management-plane service-disable flags. Junos checks SSH version, direct root SSH access and explicitly enabled Telnet. Absence of a setting never becomes a pass.

Supported syntax is tested using the included **synthetic fixtures**, not certified across every listed device/release. Validate with representative device exports before audit reliance. Version markers are checked when available. PAN-OS XML schema versions are not treated as installed firmware; the auditor-declared OS release and its provenance remain visible in findings and reports. Exports remain offline; no device login, scanning or changes occur.

**Scope limits:** no NX-OS, ASA, Aruba CX or Comware parser; no Panorama template resolution; no Junos brace syntax or inheritance evaluation. Junos groups, deactivation and logical systems force manual review. Cisco checks cover exported VTY ranges only. ACL effectiveness, segmentation, logging delivery, firmware advisories and operational controls still need human evidence. Other devices can use manually reviewed requirements or explicit normalized equality checks.

Use **Internal baseline** in the advanced catalog for these four Aegis policies. Existing asset groups, source/version snapshots, exceptions, validation and retest history are preserved. Router entries are available for Cisco IOS/IOS XE and Juniper MX; Juniper SRX uses the same bounded Junos adapter. Guided review uses one representative asset family; use the advanced inventory for explicit router/firewall/switch grouping.

Source references and detailed adapter constraints are in [NETWORK_SUPPORT.md](NETWORK_SUPPORT.md). Included samples each contain one intentional failure. Never apply them to devices.

## Temporary local access

Sign-in is disabled by default. Open http://127.0.0.1:5000 to enter the workspace with administrator capabilities. Actions are attributed to "Local workspace"; individual identity and role separation are unavailable in this mode. Existing accounts and passwords are preserved. Requests must originate on loopback and use localhost or 127.0.0.1 as the host; CSRF verification remains enabled.

To restore sign-in, set `AEGIS_REQUIRE_LOGIN=1` before starting the server. Production mode always requires authentication. Restart the server and refresh the browser after changing modes.

## Earlier FortiGate guided workflow

Aegis OT helps auditors compare offline device configuration evidence with specific, versioned requirements, validate findings, document exceptions, export reports, and retest remediation. It does not scan or change live devices. Native parser coverage is listed in the multi-vendor table above; reference-only vendor listings do not imply working native checks.

From **Overview → Review configuration**, enter a device name and auditor reference, upload a native export, and click **Preview supported checks**. Inspect the detected firmware, exact baseline version and requirements, then confirm and select **Create assessment & run comparison**. The tool creates the assessment and device grouping automatically. Continue to Findings for validation and Reports for signed exports. Existing advanced assessment workflows remain available.

The catalog now shows installed content by default. Enable the reference-only checkbox to browse content that still requires importing or implementation. Retest eligibility uses fresh evidence records, avoiding timestamp collisions after quick uploads. Previewing does not create an assessment; confirmation and an unchanged file are required.

## Current Fortinet baseline

Select **Vendor hardening guide → Firewall → Fortinet → FortiGate → 7.4.x → Fortinet FortiOS 7.4 Best Practices — reviewed subset**. This new pack replaces the earlier vendor-reference approximation in the catalog. Existing activated baselines and historical runs remain frozen; select and activate the new pack explicitly for a new assessment. Do not interpret results from an old pack as the new guide assessment.

The source is Fortinet's official FortiOS 7.4 Best Practices PDF. The exact downloaded document SHA-256, source URL, revision and implementation version are in `fortinet-source.json`. Every rule links to its PDF page. The implementation covers 8 automated and 8 manual requirements, not the complete publication. The guide recommends idle timeout below ten minutes; the automated preference check uses 1–9 minutes. Nonstandard port recommendations and numeric cipher examples are identified explicitly. Aegis assigns severity; Fortinet does not provide these severity labels.

Device version `7.4` or `7.4.x` is accepted when the configuration header verifies a specific 7.4 patch. An exact version is also accepted and must match. Missing headers, omitted settings and incomplete IPv4/IPv6 evidence stay Unable to assess; no defaults are invented. For CLI output lacking a header, obtain a native full backup with its version header. The parser does not execute CLI commands. Re-upload old evidence to use parser 1.2.

Use `samples/fortinet-best-practices-7.4.5.conf` for a reproducible trial: 7 Pass, 1 Fail and 8 Manual review (88% compliance, 50% coverage). The companion `-retest.conf` removes the cleartext-access failure. This is test data, never a deployable device configuration.

**After upgrading:** stop the old server, start `py server.py` from this folder, and hard-refresh the browser. Confirm build `2026.09.24-network-review` in the sidebar/startup output. Comparison readiness displays device firmware, export firmware, baseline and evidence status. Errors remain visible on the page. Your actual device configuration has not been validated by the developer unless you provide it.

## Start locally (port 5000)

Requires Python 3.10+ and an internet connection for initial dependency installation.

```powershell
python -m pip install -r requirements.txt
python server.py
```

Open http://127.0.0.1:5000. Windows users can also run `./start.ps1` after installing dependencies. Stop any older copy using Ctrl+C in its terminal first. A second instance cannot share port 5000.

First launch creates separate `admin`, `auditor`, and `reviewer` passwords in `data/local-credentials.json`. Use the exact username and corresponding password. The file is private and never served by the application. Named local accounts are supported; SSO and MFA are not included.

## Upgrade an existing installation

1. Stop the running server. Back up the entire existing `data` directory to a protected location.
2. Extract this ZIP into a new application folder. Copy the existing `data` directory into it before the first launch, or set `AEGIS_DATA_DIR` to the existing data directory.
3. Preserve the existing encryption key and signing key. Windows-generated encryption keys are bound to the Windows user that created them. If you previously used `AEGIS_MASTER_KEY`, keep exactly the same value. Do not substitute a new random key for existing encrypted data.
4. Install requirements, then start `server.py` under the same Windows account. Existing users and assessments are preserved. Older plaintext assessment bodies are encrypted during initialization; existing backup files are not changed or encrypted.
5. Upload the native configuration again to use parser 1.2. Historical results remain unchanged. Older uploads may lack retained originals or analysis detail.

The release ZIP contains no accounts, passwords, encryption keys, or assessment database.

## Analysis improvement in this release

- Original six-check FortiOS 7.4 administrative hardening pack; parser version 1.2.
- Accepts a 7.4 family selection or an exact patch, verified against the export header. Missing or mismatched firmware cannot produce a pass.
- Supports multiline quoted certificate values without displaying their contents in finding evidence. Rejects truncated blocks, conflicting firmware headers, duplicate settings, and unsupported CLI commands.
- Findings expose checked setting snippets, context, source line numbers, evaluation reason, parser version, retained evidence reference, and remediation guidance.
- Separate compliance and assessment coverage. Compliance is Pass / (Pass + Fail). Coverage is (Pass + Fail) / applicable checks. Manual and unknown checks reduce coverage. Not applicable checks are excluded from its denominator. Zero denominators display no percentage.
- Retests classify resolved, new, recurring, reopened, changed setting, changed requirement, changed analysis engine, and unchanged results. Removed checks are scope changes, not resolutions. Evidence-content changes are reported independently from upload timestamps. Human validation remains required.

### Try the native pack

1. Create an assessment; add a Firewall asset: Fortinet / FortiGate / exact firmware `7.4.5`.
2. Select **Internal baseline**, then **Aegis FortiOS 7.4 administrative hardening**, and assign the asset group.
3. Review all six requirements and confirm activation.
4. Upload `samples/fortigate-7.4.5.conf` for that asset. Run comparison: five passes and one failure are expected.
5. Upload `samples/fortigate-7.4.5-retest.conf`, then run retest: six passes and one resolved finding are expected. All findings still await auditor/reviewer validation.

These fixtures are sanitized examples, not configurations to deploy to equipment. Native checks cover idle timeout, strong administrative cryptography, administrative TLS, lockout threshold/duration, and HTTP/Telnet interface management. They are original policy checks, not a complete FortiGate assessment or CIS certification. VDOM-dependent interface checks require manual review unless explicitly insecure access is found. Omitted defaults are never inferred. Other firmware families and vendor syntax need separately validated parsers.

## Assessment workflow

Create assessment → Add assets → Baseline selection → Review applicability → Upload configurations → Run comparison → Validate findings → Report → Retest.

Auditors prepare assessments and run comparisons. Reviewers validate findings and approve exceptions. Admins can perform both and restrict assessment access. Existing assessments remain shared until an administrator selects authorized members in **Asset inventory → Assessment access**. New assessments are assigned to their creator; admins can always access them.

### Baselines and catalog

Upload CSV/XLSX, DOCX, or text-based PDF up to 8 MB. Scanned PDFs require external OCR. The first XLSX sheet is used. Structured columns: `id,title,key,expected,mapping`. All imported requirements start as manual review. Word/PDF extraction provides draft text, not executable logic. Review metadata, requirements, applicability and mapping, then confirm activation. Activation freezes the version. Create a new version for later policy changes.

Catalog filters support asset type, vendor, product family, OS/firmware version, benchmark version and profile. The vendor directory is broader than executable parser coverage. Public CIS entries are metadata references marked **Import required**. No licensed CIS rule content is included. Confirm distribution/use rights when importing content. Framework references such as NIST or IEC 62443 are control mappings, not executable checks or certification claims.

Groups can have different baselines. Conflicting expectations block comparison until explicit precedence is recorded. Runs preserve baseline, precedence, evidence and result snapshots.

Flat JSON and `key=value` inputs remain supported for explicit normalized equality checks. Missing keys produce Unable to assess. Manual requirements remain Manual review.

### Evidence, exceptions and reports

New uploads retain encrypted originals and SHA-256 digests. Assessment bodies are encrypted using AES-256-GCM. Evidence download verifies decryption and digest and requires assessment access. Older uploads cannot recover originals that were never retained.

Exceptions require justification, approval reference and expiry. Findings show countdown and approval identity. An approved exception never changes the technical Pass/Fail result. Signed reports show exception state at export time.

Required result columns are Asset | Baseline and version | Rule | Expected setting | Observed setting | Status | Evidence. Search, sort, status filters and unsigned filtered CSV remain available. Signed full-run CSV/PDF downloads are ZIP packages containing the report, a SHA-256 manifest, detached Ed25519 signature and public key. This is not an embedded PDF certificate signature or trusted timestamp.

Obtain the signing fingerprint from your administrator through a trusted channel:

```powershell
python manage.py signer-fingerprint
python verify_report.py REPORT.zip --trusted-fingerprint YOUR_TRUSTED_FINGERPRINT
```

Do not trust a fingerprint solely because it accompanies the report. Protect the signing key and distribute its fingerprint independently.

## Local account administration

```powershell
python manage.py create-user alice --role admin
python manage.py create-user bob --role auditor
python manage.py change-password alice
python manage.py disable-user auditor
python manage.py list-users
python manage.py verify-audit
```

Password prompts require at least 14 characters. Password changes and disabling users revoke their sessions at the next request. Sessions expire after 30 minutes idle or 8 hours absolute. Failed logins are throttled in memory.

## Keys and deployment boundaries

The application serves through Flask/Waitress on loopback port 5000. It performs offline review; it does not execute uploads, scan equipment, or change device configuration.

Default Windows keys use DPAPI under the current Windows account. On other platforms, the local key file uses owner-only permissions. An externally managed base64-encoded 32-byte `AEGIS_MASTER_KEY` can be supplied instead. Back up data and keys securely; losing or changing keys can make records unreadable. Filesystem administrators and a compromised running host remain within the trust boundary.

For shared hosting, deploy behind a properly configured TLS reverse proxy and perform an organizational security review. `AEGIS_PRODUCTION=1` requires `AEGIS_MASTER_KEY`, HTTPS `AEGIS_PUBLIC_URL`, and disabling the shared starter usernames after creating named accounts. Signed exports also require externally managed `AEGIS_SIGNING_KEY` (base64 raw 32-byte Ed25519 private key). No automatic secret-store integration or certificate provisioning is included. Keep the app loopback-bound. The proxy must preserve the configured public origin; forwarded client-IP trust is not enabled, so the application IP throttle may aggregate proxy users.

This is a single-process application: sessions and throttling reset on restart. Backups, recovery drills, retention, off-host audit checkpoints, and trusted signing-key distribution are operator responsibilities. The HMAC audit chain detects altered records but cannot independently detect a complete database rollback or tail truncation. Existing plaintext backups must be secured separately. Accessibility improvements include keyboard navigation, labels, focus states and contrast; this release is not certified for WCAG compliance.

## Regression tests

```powershell
python run_tests.py
```

Tests use temporary databases and a disposable key. They cover native parser uncertainty, source provenance, coverage, retest classification, workflow authorization, baseline licensing gates, encrypted evidence, report signatures/tampering, and document parsing. Do not use a disposable test key to start the real database.

