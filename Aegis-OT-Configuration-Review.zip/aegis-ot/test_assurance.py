import base64,io,json,os,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
import server
from fortigate import parse,evaluate,catalog_entry
from security import Vault,LoginLimiter
from reports import export_bundle
from verify_report import verify
from webapp import create_app

FIXTURE=(Path(__file__).parent/'samples'/'fortigate-7.4.5.conf').read_text()

class ParserTests(unittest.TestCase):
    def test_native_checks_and_line_provenance(self):
        data=parse(FIXTURE);self.assertEqual(data['firmware'],'7.4.5');self.assertEqual(sum(s=='Pass' for s in data['outcomes'].values()),5);self.assertEqual(data['outcomes']['fg.cleartext_management'],'Fail');self.assertTrue(data['checks']['fg.admin_tls']['lines'])
    def test_missing_defaults_not_invented(self):
        data=parse('config system global\n set hostname "test"\nend')
        self.assertEqual(set(data['outcomes'].values()),{'Unable to assess'})
    def test_truncated_and_script_commands_rejected(self):
        for text in ['config system global\n set admintimeout 10','execute reboot','config system global\n set admintimeout "10\nend']:
            with self.assertRaises(ValueError):parse(text)
    def test_vdom_and_interface_unknown(self):
        data=parse('config vdom\n edit root\n config system interface\n edit port1\n set allowaccess https ssh\n next\n end\n next\nend')
        self.assertEqual(data['outcomes']['fg.cleartext_management'],'Manual review')
    def test_firmware_and_custom_policy_fail_closed(self):
        config=parse(FIXTURE);rule=catalog_entry()['rules'][0]
        self.assertEqual(evaluate(config,rule,{'version':'7.4.6'})[0],'Unable to assess')
        self.assertEqual(evaluate({},rule,{'version':'7.4.5'})[0],'Unable to assess')
        rule['expected']='unvalidated policy';self.assertEqual(evaluate(config,rule,{'version':'7.4.5'})[0],'Manual review')

class AssuranceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.old=server.DB;server.DB=Path(self.tmp.name)/'data'/'audit.db';server.init();self.app=create_app(server);self.client=self.app.test_client();self.passwords=json.loads((server.DB.parent/'local-credentials.json').read_text());self.login('admin');self.a=server.load('OT-2026-001')
    def tearDown(self):server.DB=self.old;self.tmp.cleanup()
    def login(self,role):
        r=self.client.post('/api/login',json={'name':role,'password':self.passwords[role]});self.assertEqual(r.status_code,200);self.csrf=self.client.get('/api/state').json['user']['csrf']
    def action(self,action,**kwargs):return self.client.post('/api/action',json={'action':action,'assessment':'OT-2026-001',**kwargs},headers={'X-CSRF-Token':self.csrf})
    def native_run(self,entry='aegis-fortios74',encoding='utf-8'):
        asset=self.a['assets'][0];asset.update(vendor='Fortinet',family='FortiGate',version='7.4.5');self.a['baselines']=[];server.save(self.a)
        self.assertEqual(self.action('catalog',entry=entry,group='Perimeter',license=True).status_code,200)
        baseline=server.load(self.a['id'])['baselines'][0]
        self.assertEqual(self.action('activate',baseline=baseline['id'],confirmed=True).status_code,200)
        self.assertEqual(self.action('config',asset=asset['id'],filename='device.conf',data=base64.b64encode(FIXTURE.encode(encoding)).decode()).status_code,200)
        self.assertEqual(self.action('run').status_code,200);return server.load(self.a['id'])
    def test_encrypted_original_and_access(self):
        a=self.native_run();evidence=a['configs'][a['assets'][0]['id']]['evidenceId']
        self.assertEqual(self.client.get('/api/evidence/'+evidence).data,FIXTURE.encode())
        with server.database() as c:
            body=c.execute('SELECT body FROM assessments WHERE id=?',(a['id'],)).fetchone()[0];blob=c.execute('SELECT encrypted FROM evidence WHERE id=?',(evidence,)).fetchone()[0]
        self.assertTrue(body.startswith('ENC1:'));self.assertNotIn(b'TEST-FORTIGATE',blob)
        self.assertEqual(self.action('members',members=['admin']).status_code,200);self.login('reviewer')
        self.assertEqual(self.client.get('/api/evidence/'+evidence).status_code,403)
        self.assertNotIn(a['id'],[a['id'] for a in self.client.get('/api/state').json['assessments']])
    def test_signed_exports_and_tampering(self):
        a=self.native_run();run=a['runs'][-1]
        for fmt in ['csv','pdf']:
            response=self.client.post('/api/report',json=dict(assessment=a['id'],run=run['id'],format=fmt),headers={'X-CSRF-Token':self.csrf});self.assertEqual(response.status_code,200)
            path=Path(self.tmp.name)/('report-'+fmt+'.zip');path.write_bytes(response.data)
            with zipfile.ZipFile(path) as z:manifest=json.loads(z.read('manifest.json'));parts={n:z.read(n) for n in z.namelist()}
            self.assertEqual(verify(path,manifest['signingKeySHA256'])['rows'],6)
            parts['report.'+fmt]+=b'TAMPER'
            with zipfile.ZipFile(path,'w') as z:
                for n,raw in parts.items():z.writestr(n,raw)
            with self.assertRaises(ValueError):verify(path,manifest['signingKeySHA256'])
    def test_audit_and_evidence_tamper_detection(self):
        a=self.native_run();self.assertTrue(server.verify_audit()['valid']);eid=a['configs'][a['assets'][0]['id']]['evidenceId']
        with server.database() as c:
            c.execute("UPDATE audit_log SET payload='modified' WHERE seq=1")
            c.execute('UPDATE evidence SET encrypted=? WHERE id=?',(b'broken',eid))
        self.assertFalse(server.verify_audit()['valid']);self.assertEqual(self.client.get('/api/evidence/'+eid).status_code,409)
    def test_login_throttle_and_password_change_revocation(self):
        limit=LoginLimiter()
        for i in range(5):limit.failed('client','user')
        self.assertFalse(limit.allowed('client','user'))
        with server.database() as c:c.execute("UPDATE users SET digest='changed' WHERE name='admin'")
        self.assertEqual(self.client.get('/api/state').status_code,401)
    def test_role_cannot_grant_access(self):
        self.login('auditor');self.assertEqual(self.action('members',members=['auditor']).status_code,403)
    def test_vendor_source_selection_and_utf16_configuration(self):
        a=self.native_run(entry='fortinet-bp74-reviewed-v2',encoding='utf-16')
        self.assertEqual(a['baselines'][0]['source'],'Vendor hardening guide')
        self.assertEqual(len(a['runs'][-1]['rows']),16)
        self.assertEqual(sum(r['status']=='Pass' for r in a['runs'][-1]['rows']),1)
    def test_xml_disguised_as_text_rejected_with_explanation(self):
        r=self.action('config',asset=self.a['assets'][0]['id'],filename='device.txt',data=base64.b64encode(b'<config firmware="7.4.5"/>').decode())
        self.assertEqual(r.status_code,400);self.assertIn('XML',r.json['error'])
    def guided_request(self,path,**extra):
        raw=(Path(__file__).parent/'samples'/'fortinet-best-practices-7.4.5.conf').read_bytes()
        data=dict(filename='device.conf',data=base64.b64encode(raw).decode(),**extra)
        return self.client.post('/api/'+path,json=data,headers={'X-CSRF-Token':self.csrf})
    def test_guided_preview_does_not_create_assessment(self):
        before=len(self.client.get('/api/state').json['assessments'])
        preview=self.guided_request('config-preview');self.assertEqual(preview.status_code,200)
        self.assertEqual(preview.json['firmware'],'7.4.5');self.assertEqual(preview.json['summary']['counts']['Fail'],1)
        self.assertEqual(len(self.client.get('/api/state').json['assessments']),before)
        with server.database() as c:self.assertEqual(c.execute('SELECT count(*) FROM evidence').fetchone()[0],0)
    def test_guided_review_creates_traceable_result_without_inventory_setup(self):
        p=self.guided_request('config-preview').json
        response=self.guided_request('config-review',previewHash=p['hash'],confirmed=True,device='PLANT-FW',auditorReference='AUD-REF')
        self.assertEqual(response.status_code,200)
        a=server.load(response.json['id']);self.assertEqual(a['assets'][0]['version'],'7.4.5');self.assertEqual(a['members'],['admin'])
        self.assertEqual(len(a['runs'][0]['rows']),16);self.assertEqual(a['runs'][0]['analysis']['counts']['Pass'],7)
        self.assertEqual(a['baselines'][0]['approval'],'AUD-REF');self.assertTrue(a['baselines'][0]['confirmed'])
    def test_guided_requires_confirmation_and_unchanged_preview(self):
        p=self.guided_request('config-preview').json
        for extras in [dict(previewHash=p['hash'],confirmed=False),dict(previewHash='changed',confirmed=True)]:
            response=self.guided_request('config-review',device='PLANT-FW',auditorReference='AUD-REF',**extras)
            self.assertEqual(response.status_code,400)
        self.assertEqual(len(self.client.get('/api/state').json['assessments']),1)
    def test_guided_reviewer_cannot_create_or_preview(self):
        self.login('reviewer')
        self.assertEqual(self.guided_request('config-preview').status_code,403)
        self.assertEqual(self.guided_request('config-review').status_code,403)
    def test_native_retest_records_resolution_and_coverage(self):
        a=self.native_run();self.assertEqual(a['runs'][-1]['analysis']['coverage'],100)
        self.assertEqual(self.action('run',retest=True).status_code,400)
        fixed=FIXTURE.replace('https ssh telnet','https ssh')
        self.assertEqual(self.action('config',asset=a['assets'][0]['id'],filename='retest.conf',data=base64.b64encode(fixed.encode()).decode()).status_code,200)
        # Fresh evidence must qualify even when the clock has not advanced.
        current=server.load(a['id']);current['configs'][a['assets'][0]['id']]['time']=a['runs'][-1]['time'];server.save(current)
        self.assertEqual(self.action('run',retest=True).status_code,200)
        runs=server.load(a['id'])['runs'];self.assertEqual(len(runs),2)
        row=next(r for r in runs[-1]['rows'] if r['rule']=='FG-006')
        self.assertEqual(row['change']['kind'],'Resolved');self.assertEqual(row['review'],'Pending')
        self.assertEqual(runs[-1]['analysis']['compliance'],100)

if __name__=='__main__':unittest.main(verbosity=2)
