"""OT Audit Workbench. Local server: python server.py (http://127.0.0.1:5000)."""
if __name__ == '__main__':
    import importlib.util, sys
    from pathlib import Path
    missing = [name for name in ('cryptography', 'flask', 'waitress', 'openpyxl', 'docx', 'pypdf', 'reportlab') if importlib.util.find_spec(name) is None]
    if missing:
        requirements = Path(__file__).resolve().with_name('requirements.txt')
        raise SystemExit('Missing application dependencies: ' + ', '.join(missing) + '\nInstall them using this same Python interpreter:\n"' + sys.executable + '" -m pip install -r "' + str(requirements) + '"\nThen run server.py again, or use start.cmd for an isolated setup.')
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from datetime import datetime, timezone, date, timedelta
import base64, csv, hashlib, hmac, io, json, os, secrets, socket, sqlite3, threading, uuid, zipfile
from contextlib import contextmanager
from urllib.parse import urlparse
from security import Vault, LIMITER
from fortigate import parse as parse_fortigate, evaluate as evaluate_fortigate, catalog_entry as fortigate_entry
from benchmark_catalog import PRODUCTS, REFERENCES, applies, catalog_matches
from analysis import annotate
from fortinet_best_practices import catalog_entry as official_fortinet_entry, evaluate as evaluate_best_practices
import network_devices as network

BUILD = '2026.09.24-network-review'
LOCAL_CSRF = secrets.token_urlsafe(32)

def local_workspace():
    return os.getenv('AEGIS_REQUIRE_LOGIN','0') != '1' and os.getenv('AEGIS_PRODUCTION') != '1'
ROOT = Path(__file__).resolve().parent
DB = Path(os.getenv('AEGIS_DATA_DIR',str(ROOT / 'data'))) / 'audit.db'
LOCK = threading.RLock()
SESSIONS = {}
VAULTS = {}
def vault():
    key=str(DB.parent.resolve())
    if key not in VAULTS: VAULTS[key]=Vault(DB.parent)
    return VAULTS[key]
def decode(body):return vault().decode(body,'assessment')
def can_access(a,user):return user['role']=='admin' or 'members' not in a or user['name'] in a['members']
def public_origin():return os.getenv('AEGIS_PUBLIC_URL','http://127.0.0.1:5000').rstrip('/')
def cookie(token,logout=False):return 'ot_session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+('0' if logout else '28800')+('; Secure' if public_origin().startswith('https://') else '')
def audit(aid,actor,action,detail=''):
    with LOCK, database() as c:
        previous=c.execute('SELECT signature FROM audit_log ORDER BY seq DESC LIMIT 1').fetchone()
        prev=previous[0] if previous else ''
        payload=json.dumps(dict(assessment=aid,actor=actor,action=action,detail=detail,time=now()),sort_keys=True)
        signature=vault().mac(prev+payload)
        c.execute('INSERT INTO audit_log (payload,previous,signature) VALUES (?,?,?)',(payload,prev,signature))
def retain(aid,filename,raw,user):
    eid=uid();digest=hashlib.sha256(raw).hexdigest()
    with database() as c:c.execute('INSERT INTO evidence VALUES (?,?,?,?,?,?,?)',(eid,aid,filename,digest,now(),user['name'],vault().seal(raw,'evidence:'+eid)))
    audit(aid,user['name'],'Evidence retained',eid+' '+digest)
    return eid
def verify_audit():
    prev='';count=0
    with database() as c:
        for payload,previous,signature in c.execute('SELECT payload,previous,signature FROM audit_log ORDER BY seq'):
            if previous!=prev or not hmac.compare_digest(signature,vault().mac(prev+payload)):return dict(valid=False,records=count)
            prev=signature;count+=1
    return dict(valid=True,records=count,head=prev)

@contextmanager
def database():
    connection=sqlite3.connect(DB)
    try:
        with connection:
            yield connection
    finally:
        connection.close()

def uid(): return uuid.uuid4().hex[:12]
def now(): return datetime.now(timezone.utc).isoformat()
def rule(i, title, key, expected, mapping='NIST SP 800-82: configuration management'):
    return dict(id=i,title=title,key=key,expected=expected,mode='automated',applicable=True,mapping=mapping)
def baseline():
    return dict(id=uid(),name='Plant network hardening',version='2.1',source='Internal baseline',approval='SEC-2026-014',date='2026-08-20',devices='Firewall',group='Perimeter',confirmed=True,active=True,filename='Bundled sample',hash='',rules=[rule('NET-01','Disable Telnet administration','telnet_enabled','false'),rule('NET-02','Forward security events','syslog_enabled','true'),rule('NET-03','Use an approved time source','ntp_server','10.20.0.10'),rule('NET-04','Restrict administration network','management_network','10.20.10.0/24')])
def seed():
    b=baseline()
    return dict(id='OT-2026-001',name='North plant · Configuration assurance',site='North manufacturing plant',owner='Security assurance',created=now(),assets=[dict(id=uid(),name=n,group=g,product=p,version=v,criticality=c) for n,g,p,v,c in [('FW-NORTH-01','Perimeter','Firewall','7.4','Critical'),('FW-NORTH-02','Perimeter','Firewall','7.4','High'),('SW-CELL-01','Production','Switch','17.9','High'),('SW-CELL-02','Production','Switch','17.9','Medium'),('ENG-WS-01','Engineering','Windows Server','2022','Critical'),('SCADA-SRV-01','Engineering','Windows Server','2022','Critical')]],baselines=[b],configs={},runs=[],exceptions=[],precedence={},events=[dict(time=now(),actor='System',action='Created sample assessment; all sample rules are illustrative.')])
def init():
    DB.parent.mkdir(exist_ok=True)
    vault()
    with database() as c:
        c.execute('CREATE TABLE IF NOT EXISTS assessments (id TEXT PRIMARY KEY, body TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS users (name TEXT PRIMARY KEY, role TEXT, salt TEXT, digest TEXT)')
        columns={r[1] for r in c.execute('PRAGMA table_info(users)')}
        if 'active' not in columns:c.execute('ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1')
        c.execute('CREATE TABLE IF NOT EXISTS evidence (id TEXT PRIMARY KEY, assessment TEXT, filename TEXT, digest TEXT, created TEXT, actor TEXT, encrypted BLOB)')
        c.execute('CREATE TABLE IF NOT EXISTS audit_log (seq INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT, previous TEXT, signature TEXT)')
        c.execute('PRAGMA secure_delete=ON')
        for existing_id,body in c.execute('SELECT id,body FROM assessments').fetchall():
            if not body.startswith('ENC1:'):c.execute('UPDATE assessments SET body=? WHERE id=?',(vault().encode(json.loads(body),'assessment'),existing_id))
        if not c.execute('SELECT 1 FROM assessments').fetchone():
            a=seed(); c.execute('INSERT INTO assessments VALUES (?,?)',(a['id'],vault().encode(a,'assessment')))
        if not c.execute('SELECT 1 FROM users').fetchone():
            passwords={}
            for role in ['admin','auditor','reviewer']:
                password=secrets.token_urlsafe(12); salt=secrets.token_hex(16)
                digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),200000).hex()
                c.execute('INSERT INTO users (name,role,salt,digest) VALUES (?,?,?,?)',(role,role,salt,digest)); passwords[role]=password
            (DB.parent/'local-credentials.json').write_text(json.dumps(passwords,indent=2))
def load(aid):
    with database() as c:
        row=c.execute('SELECT body FROM assessments WHERE id=?',(aid,)).fetchone()
    if not row: raise ValueError('Assessment not found.')
    return decode(row[0])
def save(a):
    with database() as c: c.execute('INSERT OR REPLACE INTO assessments VALUES (?,?)',(a['id'],vault().encode(a,'assessment')))
def require(value,message):
    if not value: raise ValueError(message)
def filedata(d,extensions):
    filename=Path(d.get('filename','')).name; ext=Path(filename).suffix.lower()
    require(ext in extensions,'Unsupported file type. Use '+', '.join(extensions))
    raw=base64.b64decode(d.get('data',''),validate=True)
    require(0<len(raw)<=8*1024*1024,'File must be between 1 byte and 8 MB.')
    if ext in ['.xlsx','.docx']:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            require(sum(x.file_size for x in z.infolist())<40*1024*1024,'Expanded document exceeds 40 MB.')
    return filename,ext,raw
def extract(ext,raw):
    if ext=='.csv': rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
    elif ext=='.xlsx':
        import openpyxl
        w=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=True); sheet=w.active
        values=list(sheet.iter_rows(values_only=True)); require(values,'Workbook is empty.')
        rows=[dict(zip([str(v or '').strip().lower() for v in values[0]],v)) for v in values[1:]]; w.close()
    else:
        if ext=='.docx':
            from docx import Document
            doc=Document(io.BytesIO(raw)); lines=[p.text for p in doc.paragraphs]+[' | '.join(c.text for c in r.cells) for t in doc.tables for r in t.rows]
        else:
            from pypdf import PdfReader
            lines='\n'.join(p.extract_text() or '' for p in PdfReader(io.BytesIO(raw)).pages).splitlines()
        rows=[{'title':s.strip()} for s in lines if len(s.strip())>8]
    require(0<len(rows)<=500,'No requirements found or more than 500 rows. Scanned PDFs require OCR before upload.')
    result=[]
    for i,row in enumerate(rows):
        row={str(k).strip().lower():str(v if v is not None else '').strip() for k,v in row.items()}
        title=row.get('title') or row.get('requirement') or row.get('description')
        require(title,'Structured files need a title or requirement column.')
        result.append(dict(id=row.get('id') or f'UP-{i+1:03}',title=title,key=row.get('key',''),expected=row.get('expected',''),mode='manual',applicable=True,mapping=row.get('mapping','')))
    require(len({r['id'] for r in result})==len(result),'Rule IDs must be unique.')
    return result
CATALOG=[]
for product,version in [('Firewall','7.4'),('Switch','17.9'),('Windows Server','2022')]:
    CATALOG.append(dict(id='sample-'+product,name=product+' security baseline',source='Internal baseline',product=product,productVersion=version,version='1.0',profile='Standard',license='Original illustrative rules · included',rules=[rule('CFG-01','Disable legacy management','telnet_enabled','false'),rule('CFG-02','Enable security event forwarding','syslog_enabled','true'),rule('CFG-03','Set session idle timeout','idle_timeout_minutes','15')]))
def catalog_entries(assessments=None,user=None):
    if assessments is None:
        with database() as c: assessments=[decode(r[0]) for r in c.execute('SELECT body FROM assessments')]
    if user:assessments=[a for a in assessments if can_access(a,user)]
    entries=[dict(e,installed=True,vendor='',family='',os='') for e in CATALOG]+REFERENCES+[fortigate_entry(),official_fortinet_entry()]+network.catalog_entries()
    for assessment in assessments:
        for b in assessment['baselines']:
            if b['active'] and b.get('vendor') and b.get('family') and b.get('productVersion'):
                entries.append(dict(id='import-'+b['id'],name=b['name'],source=b['source'],product=b['devices'],vendor=b['vendor'],family=b['family'],os=b.get('os',''),productVersion=b['productVersion'],version=b['version'],profile=b.get('profile',''),installed=True,rules=b['rules'],license='Approved import · '+b['approval'],hash=b.get('hash','')))
    return entries

def conflicts(a):
    out=[]
    for asset in a['assets']:
        keys={}
        for b in a['baselines']:
            if not b['active'] or not applies(b,asset): continue
            for r in b['rules']:
                if r['applicable'] and r['mode']=='automated': keys.setdefault(r['key'],[]).append((b,r))
        for setting,items in keys.items():
            if len(set(r['expected'] for b,r in items))>1:
                key=asset['id']+'|'+setting
                ids=[b['id']+'|'+r['id'] for b,r in items]
                out.append(dict(key=key,label=asset['name']+' · '+setting,choices=[dict(id=b['id']+'|'+r['id'],label=b['name']+' '+b['version']+' / '+r['id']+' = '+r['expected']) for b,r in items],selected=a['precedence'].get(key) if a['precedence'].get(key) in ids else None))
    return out

def process(a,action,d,user):
    if action in ['add_asset','update_asset']:
        require(d.get('name') and d.get('group') and d.get('version'),'Name, group and version are required.')
        require(not any(x['name']==d['name'] and x['id']!=d.get('asset') for x in a['assets']),'Asset name already exists.')
        if d.get('vendor') or d.get('family'):
            require(any(p['product']==d['product'] and p['vendor']==d.get('vendor') and p['family']==d.get('family') for p in PRODUCTS),'Choose a valid vendor and product family.')
        values={k:d[k] for k in ['name','group','product','version','criticality']}
        values.update({k:d.get(k,'') for k in ['vendor','family','os']})
        if action=='update_asset':
            asset=next(x for x in a['assets'] if x['id']==d['asset']); asset.update(values)
        else: a['assets'].append(values|{'id':uid()})
    elif action=='upload_baseline':
        for k in ['name','version','approval','date','devices','group']: require(d.get(k),'Complete all baseline metadata fields.')
        require(date.fromisoformat(d['date'])<=date.today(),'Approval date cannot be in the future.')
        filename,ext,raw=filedata(d,['.csv','.xlsx','.docx','.pdf'])
        rules=extract(ext,raw)
        scoped=any(d.get(k) for k in ['vendor','family','productVersion'])
        if scoped:
            require(all(d.get(k) for k in ['vendor','family','productVersion']),'Vendor, product family and firmware scope are required together.')
            require(any(p['product']==d['devices'] and p['vendor']==d['vendor'] and p['family']==d['family'] for p in PRODUCTS),'Product scope does not match the product directory.')
            require(d.get('rights'),'Confirm authorization to use this baseline content.')
        if d.get('source')=='CIS': require(scoped and d.get('rights'),'CIS imports require vendor/product/version scope and content-use authorization.')
        a['baselines'].append({k:d[k] for k in ['name','version','approval','date','devices','group']}|dict(id=uid(),source=d.get('source','Internal baseline'),vendor=d.get('vendor',''),family=d.get('family',''),os=d.get('os',''),productVersion=d.get('productVersion',''),profile=d.get('profile',''),confirmed=False,active=False,filename=filename,hash=hashlib.sha256(raw).hexdigest(),evidenceId=retain(a['id'],filename,raw,user),rules=rules))
    elif action=='catalog':
        entry=next((x for x in catalog_entries(user=user) if x['id']==d['entry']),None); require(entry and entry.get('installed'),'Benchmark requirements are not installed. Import authorized content first.')
        require(d.get('license'),'Confirm the content usage terms.')
        require(any(x['group']==d['group'] and catalog_matches(entry,x) for x in a['assets']),'No matching product/version in this asset group.')
        a['baselines'].append(dict(id=uid(),name=entry['name'],version=entry['version'],source=entry['source'],devices=entry['product'],vendor=entry.get('vendor',''),family=entry.get('family',''),os=entry.get('os',''),productVersion=entry['productVersion'],profile=entry['profile'],group=d['group'],approval='Catalog selection',date=date.today().isoformat(),confirmed=False,active=False,filename='Catalog',hash=entry.get('hash',''),rules=json.loads(json.dumps(entry['rules']))))
    elif action=='rules':
        b=next(x for x in a['baselines'] if x['id']==d['baseline']); require(not b['active'],'Active versions are frozen. Upload a new version to change rules.')
        rules=d['rules']; require(0<len(rules)<=500,'Invalid rule count.')
        require(len({r['id'] for r in rules})==len(rules),'Rule IDs must be unique.')
        for r in rules:
            require(r['mode'] in ['manual','automated'],'Invalid check mode.')
            require(r['title'] and r['id'],'Rule title and ID are required.')
            if r['mode']=='automated': require(r['key'] and r['expected']!='','Automated checks require a key and expected value.')
        b['rules']=rules; b['confirmed']=False
    elif action=='activate':
        b=next(x for x in a['baselines'] if x['id']==d['baseline'])
        require(d.get('confirmed'),'Auditor confirmation is required.')
        require(any(r['applicable'] for r in b['rules']),'At least one rule must apply.')
        b['active']=True; b['confirmed']=True; b['confirmedBy']=user['name']; b['confirmedAt']=now()
    elif action=='precedence':
        conflict=next((x for x in conflicts(a) if x['key']==d['key']),None)
        require(conflict and d['choice'] in [x['id'] for x in conflict['choices']],'Invalid precedence decision.')
        a['precedence'][d['key']]=d['choice']
    elif action=='config':
        require(any(x['id']==d['asset'] for x in a['assets']),'Unknown asset.')
        filename,ext,raw=filedata(d,['.json','.txt','.conf','.cfg','.xml','.set'])
        try:text=raw.decode('utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
        except UnicodeError:raise ValueError('Configuration encoding is not supported. Export unencrypted plain text in UTF-8 or UTF-16 with a byte-order mark.')
        require('\x00' not in text,'This appears to be binary or encrypted content. Upload an unencrypted plain-text configuration export.')
        asset=next(x for x in a['assets'] if x['id']==d['asset'])
        platform=network.platform_for(asset)
        require(platform=='paloalto-panos' or not text.lstrip().startswith('<'),'XML requires a supported Palo Alto standalone configuration and matching device details.')
        native=(ext!='.json' and any(line.strip().startswith('config ') for line in text.splitlines()))
        details={}
        if platform and ext!='.json':
            details=network.parse(text,platform,asset['version']);values=details.pop('values')
        elif native:
            require(asset.get('vendor')=='Fortinet' and asset.get('family')=='FortiGate','Native parsing currently supports FortiGate only. Check the asset vendor and product.')
            details=parse_fortigate(text);values=details.pop('values')
            declared=asset['version'].strip();actual=details.get('firmware')
            require(not actual or actual==declared or (declared in ['7.4','7.4.x'] and actual.startswith('7.4.')),'The export firmware differs from the asset version. Correct the device details or upload the right file.')
        elif ext=='.json':
            values=json.loads(text);require(isinstance(values,dict) and all(isinstance(v,(str,int,float,bool)) or v is None for v in values.values()),'Use a flat JSON object with scalar settings.')
        else:
            values={}
            for line in text.splitlines():
                if '=' in line and not line.lstrip().startswith('#'):
                    k,v=line.split('=',1);values[k.strip()]=v.strip()
            require(values,'Supply a FortiGate export, flat JSON, or key=value configuration.')
        a['configs'][d['asset']]=dict(filename=filename,hash=hashlib.sha256(raw).hexdigest(),time=now(),collector=user['name'],evidenceId=retain(a['id'],filename,raw,user),values={k:str(v).lower() if isinstance(v,bool) else str(v) for k,v in values.items()},**details)
    elif action=='run':
        require(any(b['active'] for b in a['baselines']),'Activate a baseline first.')
        require(not any(not x['selected'] for x in conflicts(a)),'Resolve all baseline conflicts before comparison.')
        if d.get('retest'):
            require(a['runs'],'Run an initial comparison first.')
            previous_configs=a['runs'][-1].get('configs',{})
            require(any(c.get('evidenceId') != previous_configs.get(asset_id,{}).get('evidenceId') if c.get('evidenceId') else c != previous_configs.get(asset_id,{}) for asset_id,c in a['configs'].items()),'Upload fresh configuration evidence before retesting.')
        rows=[]; conflictkeys={x['key'] for x in conflicts(a)}
        for asset in a['assets']:
            for b in a['baselines']:
                if not b['active'] or not applies(b,asset): continue
                config=a['configs'].get(asset['id'])
                for r in b['rules']:
                    ck=asset['id']+'|'+r['key']; overridden=ck in conflictkeys and a['precedence'][ck]!=b['id']+'|'+r['id']
                    observed=config['values'].get(r['key']) if config else None
                    check_evidence={}
                    if not r['applicable'] or overridden: status='Not applicable'
                    elif r['mode']=='manual': status='Manual review'
                    elif r.get('engine')=='fortigate': status,observed,check_evidence=evaluate_fortigate(config or {},r,asset)
                    elif r.get('engine')=='fortinet-best-practices': status,observed,check_evidence=evaluate_best_practices(config or {},r,asset)
                    elif r.get('engine')=='network-native': status,observed,check_evidence=network.evaluate(config or {},r,asset)
                    elif observed is None: status='Unable to assess'
                    else: status='Pass' if observed==r['expected'] else 'Fail'
                    rows.append(dict(id=uid(),asset=asset['name'],assetId=asset['id'],baseline=b['name'],baselineId=b['id'],version=b['version'],rule=r['id'],title=r['title'],expected=r['expected'] or 'Manual procedure',observed=observed if observed is not None else 'Not available',status=status,evidence=(config['filename']+' · SHA256 '+config['hash']) if config else 'No configuration supplied',evidenceTime=config['time'] if config else None,review='Pending',note='',mapping=r['mapping'],overridden=overridden,checkEvidence=check_evidence,evidenceId=config.get('evidenceId') if config else None,category=r.get('category','General'),versionSource=config.get('versionSource','Export header') if config else 'Unknown',severity=r.get('severity','Unrated'),remediation=r.get('remediation',''),reference=r.get('reference',''),baselineSource=b['source'],baselineHash=b.get('hash',''),firmware=config.get('firmware') if config else None))
        require(rows,'No baseline applies to the current assets.')
        run=dict(id=uid(),time=now(),type='Retest' if d.get('retest') else 'Initial comparison',rows=rows,baselines=json.loads(json.dumps(a['baselines'])),precedence=dict(a['precedence']),configs=json.loads(json.dumps(a['configs'])))
        a['runs'].append(annotate(run,a['runs']))
    elif action=='validate':
        row=next(x for x in a['runs'][-1]['rows'] if x['id']==d['finding'])
        require(d.get('note','').strip(),'A validation note or evidence reference is required.')
        require(d['review'] in ['Confirmed','Needs evidence'],'Invalid review decision.')
        row.update(review=d['review'],note=d['note'],reviewer=user['name'],reviewedAt=now())
    elif action=='exception':
        require(d.get('justification','').strip() and d.get('approval','').strip(),'Justification and approval reference are required.')
        require(date.fromisoformat(d['expiry'])>date.today(),'Expiry must be a future date.')
        row=next(x for x in a['runs'][-1]['rows'] if x['id']==d['finding'])
        a['exceptions'].append(dict(id=uid(),asset=row['asset'],baselineId=row['baselineId'],rule=row['rule'],justification=d['justification'],approval=d['approval'],expiry=d['expiry'],approvedBy=user['name'],created=now()))
    elif action=='members':
        require(user['role']=='admin','Only administrators can manage assessment access.')
        members=d.get('members',[]);require(isinstance(members,list) and members,'Select at least one named user.')
        with database() as c: valid={r[0] for r in c.execute('SELECT name FROM users WHERE active=1')}
        require(set(members)<=valid,'Unknown or disabled user.')
        a['members']=list(set(members))
    else: raise ValueError('Unknown action.')
    a['events'].append(dict(time=now(),actor=user['name'],action=action.replace('_',' ')))
    save(a);audit(a['id'],user['name'],action,hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest());return a

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def send(self,status,obj,ctype='application/json',cookie=None):
        body=json.dumps(obj).encode() if ctype=='application/json' else obj
        self.send_response(status); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(body)))
        self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self'; frame-ancestors 'none'; base-uri 'self'")
        if public_origin().startswith('https://'):self.send_header('Strict-Transport-Security','max-age=31536000')
        self.send_header('Referrer-Policy','no-referrer')
        if cookie: self.send_header('Set-Cookie',cookie)
        self.end_headers(); self.wfile.write(body)
    def session(self):
        if local_workspace():
            host=self.headers.get('Host','').lower().split(':')[0]
            if self.client_address[0] not in ('127.0.0.1','::1') or host not in ('127.0.0.1','localhost'):
                return None
            return dict(name='Local workspace',role='admin',csrf=LOCAL_CSRF,time=now(),localWorkspace=True)
        cookies=dict(p.strip().split('=',1) for p in self.headers.get('Cookie','').split(';') if '=' in p)
        s=SESSIONS.get(cookies.get('ot_session'))
        if s:
            current=now()
            if (datetime.fromisoformat(current)-datetime.fromisoformat(s['time'])).total_seconds()>28800 or (datetime.fromisoformat(current)-datetime.fromisoformat(s.get('last',s['time']))).total_seconds()>1800:return None
            with database() as c: account=c.execute('SELECT role,active,digest FROM users WHERE name=?',(s['name'],)).fetchone()
            if not account or not account[1] or (s.get('credential') and s['credential']!=account[2]):return None
            s['role']=account[0];s['last']=current;return s
        return None
    def do_GET(self):
        path=urlparse(self.path).path
        if path.startswith('/api/'):
            s=self.session()
            if not s: return self.send(401,{'error':'Sign in to continue.'})
            if path.startswith('/api/evidence/'):
                eid=path.rsplit('/',1)[-1]
                with database() as c:row=c.execute('SELECT assessment,filename,digest,encrypted FROM evidence WHERE id=?',(eid,)).fetchone()
                if not row:return self.send(404,{'error':'Evidence not found.'})
                if not can_access(load(row[0]),s):return self.send(403,{'error':'Assessment access denied.'})
                try:raw=vault().open(row[3],'evidence:'+eid)
                except Exception:return self.send(409,{'error':'Evidence integrity verification failed.'})
                if hashlib.sha256(raw).hexdigest()!=row[2]:return self.send(409,{'error':'Evidence digest mismatch.'})
                audit(row[0],s['name'],'Evidence downloaded',eid)
                return self.send(200,raw,'application/octet-stream')
            if path=='/api/audit-integrity':return self.send(200,verify_audit())
            if path=='/api/users':
                if s['role']!='admin':return self.send(403,{'error':'Administrator role required.'})
                with database() as c:users=[dict(name=r[0],role=r[1],active=bool(r[2])) for r in c.execute('SELECT name,role,active FROM users')]
                return self.send(200,users)
            if path=='/api/state':
                with database() as c: assessments=[decode(r[0]) for r in c.execute('SELECT body FROM assessments')]
                assessments=[a for a in assessments if can_access(a,s)]
                return self.send(200,dict(build=BUILD,user={k:v for k,v in s.items() if k!='credential'},assessments=assessments,catalog=catalog_entries(assessments),products=PRODUCTS,networkPlatforms=network.PLATFORMS,conflicts={a['id']:conflicts(a) for a in assessments}))
            return self.send(404,{'error':'Not found'})
        if path.startswith('/samples/'):
            target=ROOT/'samples'/Path(path).name
        else: target=ROOT/'static'/('index.html' if path=='/' else Path(path).name)
        if not target.is_file(): return self.send(404,{'error':'Not found'})
        types={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.json':'application/json','.csv':'text/csv','.txt':'text/plain'}
        self.send(200,target.read_bytes(),types.get(target.suffix,'application/octet-stream'))
    def do_POST(self):
        try:
            origin=self.headers.get('Origin')
            require(not origin or origin in ([public_origin()] if os.getenv('AEGIS_PRODUCTION')=='1' else [public_origin(),'http://localhost:5000']),'Request origin is not allowed.')
            require(self.headers.get('Content-Type','').startswith('application/json'),'JSON request required.')
            size=int(self.headers.get('Content-Length',0)); require(0<size<12*1024*1024,'Request exceeds the size limit.')
            d=json.loads(self.rfile.read(size)); path=urlparse(self.path).path
            if path=='/api/login':
                name=str(d.get('name','')).strip();d['name']=name
                if not LIMITER.allowed(self.client_address[0],name):return self.send(429,{'error':'Too many failed attempts. Wait 15 minutes before trying again.'})
                with database() as c: row=c.execute('SELECT role,salt,digest FROM users WHERE active=1 AND name=?',(d.get('name'),)).fetchone()
                valid=row and hmac.compare_digest(row[2],hashlib.pbkdf2_hmac('sha256',d.get('password','').encode(),row[1].encode(),200000).hex())
                if not valid:
                    LIMITER.failed(self.client_address[0],name);return self.send(401,{'error':'Incorrect username or password.'})
                LIMITER.success(self.client_address[0],name)
                token=secrets.token_urlsafe(32); SESSIONS[token]=dict(name=d['name'],role=row[0],csrf=secrets.token_urlsafe(24),time=now(),credential=row[2])
                return self.send(200,{'ok':True},cookie=cookie(token))
            s=self.session()
            if not s: return self.send(401,{'error':'Sign in to continue.'})
            require(hmac.compare_digest(self.headers.get('X-CSRF-Token',''),s['csrf']),'Session verification failed. Refresh and try again.')
            if path=='/api/logout':
                for token,value in list(SESSIONS.items()):
                    if value is s: del SESSIONS[token]
                return self.send(200,{'ok':True},cookie=cookie('',True))
            if path in ['/api/config-preview','/api/config-review']:
                if s['role'] not in ['admin','auditor']:return self.send(403,{'error':'Auditor or administrator role required.'})
                import config_review,sys
                core=sys.modules[__name__]
                if path=='/api/config-preview':return self.send(200,config_review.inspect(core,d)[0])
                with LOCK:assessment=config_review.create_review(core,d,s)
                return self.send(200,{'id':assessment['id']})
            if path=='/api/report':
                a=load(d['assessment'])
                if not can_access(a,s):return self.send(403,{'error':'Assessment access denied.'})
                run=next((r for r in a['runs'] if r['id']==d['run']),None);require(run,'Comparison run not found.')
                from reports import export_bundle
                with LOCK:
                    integrity=verify_audit();require(integrity['valid'],'Audit chain integrity check failed. Investigate before exporting.')
                    payload,fingerprint=export_bundle(a,run,d['format'],vault(),DB.parent,s['name'],integrity.get('head',''))
                    audit(a['id'],s['name'],'Signed report exported',run['id']+' '+d['format']+' '+fingerprint)
                return self.send(200,payload,'application/zip')
            action=d.get('action')
            allowed={'admin':{'create','add_asset','update_asset','upload_baseline','catalog','rules','activate','precedence','config','run','validate','exception','members'},'auditor':{'create','add_asset','update_asset','upload_baseline','catalog','rules','activate','precedence','config','run'},'reviewer':{'validate','exception'}}
            if action not in allowed[s['role']]: return self.send(403,{'error':'Your role cannot perform this action.'})
            with LOCK:
                if action=='create':
                    require(d.get('name') and d.get('site'),'Assessment name and site are required.')
                    a=dict(id='OT-'+uid()[:6].upper(),name=d['name'],site=d['site'],owner=s['name'],created=now(),members=[s['name']],assets=[],baselines=[],configs={},runs=[],exceptions=[],precedence={},events=[dict(time=now(),actor=s['name'],action='Created assessment')]); save(a)
                else:
                    current=load(d['assessment'])
                    if not can_access(current,s):return self.send(403,{'error':'Assessment access denied.'})
                    a=process(current,action,d,s)
            return self.send(200,{'id':a['id']})
        except (ValueError,KeyError,StopIteration,zipfile.BadZipFile,UnicodeError) as e: self.send(400,{'error':str(e) or 'Invalid selection or document.'})
        except ImportError: self.send(400,{'error':'Document parser unavailable. Install requirements.txt, or upload CSV.'})
        except Exception as e:
            print('Request error:',type(e).__name__,str(e)); self.send(400,{'error':'Unable to process this input. Verify its format and contents.'})

class LocalAuditServer(ThreadingHTTPServer):
    allow_reuse_address = False
    def server_bind(self):
        if os.name=='nt':
            self.socket.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        super().server_bind()

if __name__=='__main__':
    init()
    if os.getenv('AEGIS_PRODUCTION')=='1':
        with database() as c:
            if c.execute("SELECT 1 FROM users WHERE active=1 AND name IN ('admin','auditor','reviewer')").fetchone():raise SystemExit('Create named accounts and disable shared starter accounts before production.')
    try:
        httpd=LocalAuditServer(('127.0.0.1',5000),Handler)
    except OSError as error:
        raise SystemExit('Port 5000 is already in use. Stop the other application copy (Ctrl+C in its terminal), then run server.py again. '+str(error))
    print('Aegis OT '+BUILD+' running at http://127.0.0.1:5000',flush=True)
    print('Local workspace: sign-in disabled.' if local_workspace() else 'Local account passwords: '+str(DB.parent/'local-credentials.json'),flush=True)
    import sys
    from webapp import serve
    serve(sys.modules[__name__])
