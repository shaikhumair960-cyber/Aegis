"""Bounded, evidence-first native adapters. No device commands are executed.

These are original Aegis policies informed by linked syntax documentation, not
CIS content or complete vendor benchmarks. Unknown defaults never become passes.
"""
import hashlib
import json
import re
import shlex
import xml.etree.ElementTree as ET

VERSION = 'network-adapters/1.0'
CISCO = 'https://sec.cloudapps.cisco.com/security/center/resources/IOS_XE_hardening'
ARUBA = 'https://arubanetworking.hpe.com/techdocs/AOS-S/16.10/ASG/WC/content/common%20files/acc-sec-fea.htm'
PAN = 'https://docs.paloaltonetworks.com/ngfw/pan-os-cli-quick-start/cli-command-hierarchy/pan-os-11-2-configure-cli-command-hierarchy'
JUNOS = 'https://www.juniper.net/documentation/us/en/software/junos/cli-reference/topics/ref/statement/ssh-edit-system.html'

PLATFORMS = {
 'cisco-iosxe': dict(label='Cisco IOS / IOS XE',vendor='Cisco',family='Catalyst (IOS XE)',product='Switch',os='IOS / IOS XE',versions='IOS 15.x; IOS XE 16.x / 17.x',formats='.conf, .cfg, .txt',sample='cisco-iosxe-17.9.conf',source=CISCO),
 'aruba-aos': dict(label='Aruba / HP ProCurve (AOS-S)',vendor='HPE / Aruba (HP)',family='Aruba / ProCurve',product='Switch',os='ArubaOS-Switch',versions='16.10 / 16.11',formats='.conf, .cfg, .txt',sample='aruba-aos-16.11.conf',source=ARUBA),
 'paloalto-panos': dict(label='Palo Alto PAN-OS',vendor='Palo Alto Networks',family='PA-Series / VM-Series',product='Firewall',os='PAN-OS',versions='10.x / 11.x',formats='Standalone device XML export',sample='paloalto-11.2.xml',source=PAN),
 'juniper-junos': dict(label='Juniper Junos',vendor='Juniper Networks',family='EX / QFX Series',product='Switch',os='Junos OS',versions='21.x–24.x',formats='display set export (.set, .conf, .txt)',sample='juniper-24.2.set',source=JUNOS),
}
# Key, title, expected, category, severity. Numeric timeouts are Aegis policy.
SPECS = {
 'cisco-iosxe': [('ssh2','SSH protocol','2','Management','High'),('vty','VTY transport','SSH only or disabled on every exported VTY range','Management','High'),('http','HTTP management','Explicitly disabled','Management','High'),('aaa','AAA framework','Explicitly enabled','Authentication','Medium'),('timeout','VTY idle timeout','1–600 seconds on every exported VTY range','Authentication','Medium')],
 'aruba-aos': [('ssh','SSH service','Explicitly enabled','Management','High'),('telnet','Telnet service','Explicitly disabled','Management','High'),('http','HTTP management','Explicitly disabled','Management','High'),('https','HTTPS management','Explicitly enabled','Cryptography','Medium')],
 'paloalto-panos': [('disable-telnet','Management Telnet service','Disabled (disable-telnet=yes)','Management','High'),('disable-http','Management HTTP service','Disabled (disable-http=yes)','Management','High'),('disable-ssh','Management SSH service','Enabled (disable-ssh=no)','Management','Medium'),('disable-https','Management HTTPS service','Enabled (disable-https=no)','Cryptography','Medium')],
 'juniper-junos': [('ssh2','SSH protocol','v2','Management','High'),('root','Direct root SSH login','deny','Authentication','High'),('telnet','Telnet service','Explicit disabled evidence; absence requires review','Management','High')],
}

def supported(version,platform):
    patterns={'cisco-iosxe':r'(?:15|16|17)\.\d+[\w.()\-]*','aruba-aos':r'(?:[A-Za-z]+\.)?16\.(?:10|11)(?:\.[\w-]+)*','paloalto-panos':r'(?:10|11)\.\d+(?:\.[\w-]+)*','juniper-junos':r'(?:21|22|23|24)\.\d+[\w.\-]*'}
    return bool(re.fullmatch(patterns[platform],version))

def platform_for(asset):
    family=asset.get('family','')
    if asset.get('vendor')=='Cisco' and family in ('Catalyst (IOS XE)','Catalyst (IOS)','IOS / IOS XE Router'):return 'cisco-iosxe'
    if asset.get('vendor')=='Juniper Networks' and family in ('EX / QFX Series','SRX Series','MX Series'):return 'juniper-junos'
    return next((key for key,p in PLATFORMS.items() if p['vendor']==asset.get('vendor') and p['family']==family),None)

def entry(platform,scope=''):
    p=PLATFORMS[platform];rules=[]
    for index,(key,title,expected,category,severity) in enumerate(SPECS[platform],1):
        rules.append(dict(id=platform.upper()+'-'+str(index).zfill(2),key=platform+'.'+key,title=title,expected=expected,category=category,severity=severity,mode='automated',applicable=True,engine='network-native',platform=platform,mapping='Aegis network policy 1.0; validate organizational applicability',reference=p['source'],remediation='Review '+title.lower()+' and configure the approved setting: '+expected+'. Test management access and rollback before applying any change.'))
    for index,(title,category) in enumerate([('Management access scope and effective permissions','Authentication'),('Remote logging, time and recovery evidence','Operations'),('Software support and security advisory review','Operations')],1):
        rules.append(dict(id=platform.upper()+'-M'+str(index),key=platform+'.manual.'+str(index),title=title,expected='Auditor evidence required',category=category,severity='Unrated',mode='manual',applicable=True,mapping='Organization-specific audit procedure',reference=p['source'],remediation='Collect operational evidence and record a reviewer decision. Configuration presence alone is insufficient.'))
    digest=hashlib.sha256(json.dumps(rules,sort_keys=True).encode()).hexdigest()
    return dict(id='aegis-'+platform+'-1',name='Aegis '+p['label']+' management policy',source='Internal baseline',product=p['product'],vendor=p['vendor'],family=p['family'],os=p['os'],productVersion=scope,version='1.0',profile=f'{len(SPECS[platform])} automated + 3 manual requirements',installed=True,license='Original Aegis policy. Not CIS certification or a complete vendor benchmark.',url=p['source'],hash=digest,rules=rules,platform=platform)

def catalog_entries():
    entries=[]
    for platform in PLATFORMS:
        e=entry(platform);entries.append(e)
        if platform=='cisco-iosxe':
            entries.extend([dict(e,id=e['id']+'-ios',family='Catalyst (IOS)'),dict(e,id=e['id']+'-router',product='Router',family='IOS / IOS XE Router')])
        if platform=='juniper-junos':
            entries.extend([dict(e,id=e['id']+'-srx',product='Firewall',family='SRX Series'),dict(e,id=e['id']+'-mx',product='Router',family='MX Series')])
    return entries

def result(status='Unable to assess',observed='Setting not explicit in the supported export.',records=(),reason='Only explicit settings in the supported scope are evaluated.'):
    return dict(status=status,observed=observed,reason=reason,lines=[r[0] for r in records],snippets=[dict(line=r[0],context=r[1],setting=r[2],value='') for r in records])

def single(records,predicate):
    if not records:return result()
    if len(records)!=1:return result('Unable to assess','Repeated or conflicting settings.',records)
    r=records[0]
    return result('Pass' if predicate(r[2]) else 'Fail',r[2],records)

def cli_records(text,platform):
    records=[];context='global';banner=None;certificate=False
    for n,line in enumerate(text.splitlines(),1):
        value=line.strip()
        if banner:
            if banner in value:banner=None
            continue
        if certificate:
            if value=='quit':certificate=False
            continue
        if not value or value.startswith(('!','#',';')):continue
        if value.startswith('banner '):
            parts=value.split(maxsplit=2)
            if len(parts)<3:raise ValueError('Unsupported banner delimiter.')
            delimiter=parts[2][:2] if parts[2].startswith('^') else parts[2][0]
            if delimiter not in parts[2][len(delimiter):]:banner=delimiter
            continue
        if value.startswith('crypto pki certificate chain '):certificate=True;continue
        if not line[0].isspace():context='global'
        elif context=='global':context='nested'
        if value.startswith('line vty '):context=value;records.append((n,context,'__vty__'));continue
        records.append((n,context,value))
    if banner or certificate:raise ValueError('Truncated banner or certificate block; upload a complete export.')
    return records

def parse(text,platform,declared):
    if platform not in PLATFORMS:raise ValueError('Choose a supported platform.')
    if not supported(declared,platform):raise ValueError('Enter a supported OS release: '+PLATFORMS[platform]['versions'])
    if '\x00' in text or len(text.splitlines())>150000:raise ValueError('Binary, encrypted or excessive input is not supported.')
    checks={};detected='';warnings=['Initial management-policy subset. No reachability, full ACL semantics or vulnerability scan is performed.']
    if platform=='paloalto-panos':
        if re.search(r'<!\s*(?:DOCTYPE|ENTITY)',text,re.I):raise ValueError('XML DTDs and entities are not allowed.')
        try:root=ET.fromstring(text)
        except ET.ParseError:raise ValueError('Malformed PAN-OS XML. Export the standalone device configuration.')
        if root.tag!='config':raise ValueError('Expected a PAN-OS <config> export, not an API response or another XML format.')
        nodes=list(root.iter())
        if len(nodes)>100000:raise ValueError('XML exceeds supported node count.')
        devices=root.findall('./devices/entry')
        if len(devices)!=1 or root.find('./devices/entry/template') is not None or root.find('./devices/entry/template-stack') is not None:raise ValueError('Panorama templates or multi-device exports require a separate effective-configuration review.')
        systems=devices[0].findall('./deviceconfig/system')
        if len(systems)!=1:raise ValueError('Expected exactly one standalone device management configuration.')
        system=systems[0]
        for key,*_ in SPECS[platform]:
            path='./service/'+key;items=system.findall(path)
            if not items:checks[key]=result();continue
            if len(items)!=1 or items[0].text not in ('yes','no'):
                checks[key]=result('Unable to assess','Duplicate or unsupported XML setting.');continue
            expected='yes' if key in ('disable-telnet','disable-http') else 'no'
            checks[key]=result('Pass' if items[0].text==expected else 'Fail',items[0].text)
            checks[key]['path']='/config/devices/entry/deviceconfig/system/service/'+key
        warnings.append('PAN-OS XML schema version is not treated as the installed OS release; release is auditor-declared.')
    elif platform=='juniper-junos':
        lines=[];complex_scope=False
        for n,line in enumerate(text.splitlines(),1):
            s=line.strip()
            if not s or s.startswith('#'):continue
            if not s.startswith(('set ','deactivate ')):raise ValueError('Junos requires display set output. Brace syntax, command prompts and operational output are unsupported.')
            try:tokens=shlex.split(s)
            except ValueError:raise ValueError('Unterminated quoted value in Junos export.')
            if len(tokens)<3:raise ValueError('Incomplete Junos statement.')
            if tokens[0]=='deactivate' or tokens[1]=='groups' or 'apply-groups' in tokens or 'logical-systems' in tokens:complex_scope=True
            lines.append((n,'system services',' '.join(tokens)))
        if not any(r[2].startswith('set system ') for r in lines):raise ValueError('No Junos system configuration found.')
        versions=[r[2].split()[2] for r in lines if r[2].startswith('set version ')]
        if len(versions)>1:raise ValueError('Conflicting Junos version statements.')
        detected=versions[0] if versions else ''
        for key,prefix,expected in [('ssh2','set system services ssh protocol-version ','v2'),('root','set system services ssh root-login ','deny')]:
            records=[(n,c,s[len(prefix):]) for n,c,s in lines if s.startswith(prefix)]
            checks[key]=single(records,lambda s,e=expected:s==e)
        telnet=[(n,c,'Telnet service explicitly configured') for n,c,s in lines if s=='set system services telnet' or s.startswith('set system services telnet ')]
        checks['telnet']=result('Fail','Telnet service explicitly configured',telnet) if telnet else result()
        if complex_scope:
            checks={key:result('Manual review','Groups, deactivation or logical systems require effective-configuration review.') for key,*_ in SPECS[platform]}
    else:
        if text.lstrip().startswith('<') or re.search(r'^\s*(?:config |set system )',text,re.M):raise ValueError('File syntax does not match the selected platform.')
        records=cli_records(text,platform);globals_=[r for r in records if r[1]=='global']
        if platform=='cisco-iosxe':
            versions=[r[2].split()[1] for r in globals_ if re.fullmatch(r'version \S+',r[2])]
            if len(versions)!=1 or not any(r[2]=='end' for r in globals_):raise ValueError('Cisco requires a complete running configuration with version and end markers.')
            detected=versions[0]
            for key,pattern,good in [('ssh2',r'ip ssh version \S+','ip ssh version 2'),('http',r'(?:no )?ip http server','no ip http server'),('aaa',r'(?:no )?aaa new-model','aaa new-model')]:
                checks[key]=single([r for r in globals_ if re.fullmatch(pattern,r[2])],lambda s,g=good:s==g)
            vtys=[r for r in records if r[2]=='__vty__']
            for key,prefix in [('vty','transport input '),('timeout','exec-timeout ')]:
                outcomes=[]
                for start in vtys:
                    end=next((r[0] for r in vtys if r[0]>start[0]),len(text.splitlines())+1)
                    selected=[r for r in records if r[1]==start[1] and start[0]<r[0]<end and r[2].startswith(prefix)]
                    if key=='vty':good=lambda s:s in ('transport input ssh','transport input none')
                    else:
                        def good(s):
                            parts=s.split()[1:]
                            return len(parts) in (1,2) and all(x.isdigit() for x in parts) and (len(parts)==1 or int(parts[1])<60) and 1<=int(parts[0])*60+(int(parts[1]) if len(parts)>1 else 0)<=600
                    outcomes.append(single(selected,good))
                status='Fail' if any(o['status']=='Fail' for o in outcomes) else 'Pass' if outcomes and all(o['status']=='Pass' for o in outcomes) else 'Unable to assess'
                checks[key]=result(status,'; '.join(o['observed'] for o in outcomes) or 'No VTY ranges found.')
                checks[key]['lines']=[n for o in outcomes for n in o['lines']]
                checks[key]['snippets']=[s for o in outcomes for s in o['snippets']]
            warnings.append('VTY checks cover exported ranges only. Verify export completeness and device line inventory manually.')
        else:
            if not re.search(r'(?:ProCurve|Aruba|Configuration Editor)',text,re.I) or not any(r[2].startswith('hostname ') for r in globals_):raise ValueError('Expected an AOS-S/ProCurve export with a device header and hostname. AOS-CX and Comware use different syntax.')
            versions=re.findall(r'(?:release\s+#?|version\s+)([A-Za-z]+\.16\.(?:10|11)[\w.]*|16\.(?:10|11)[\w.]*)',text,re.I)
            if len(set(versions))>1:raise ValueError('Conflicting AOS-S version markers.')
            detected=versions[0] if versions else ''
            for key,pattern,good in [('ssh',r'(?:no )?ip ssh','ip ssh'),('telnet',r'(?:no )?telnet-server','no telnet-server'),('http',r'(?:no )?web-management(?: plaintext)?','no web-management'),('https',r'(?:no )?web-management ssl','web-management ssl')]:
                checks[key]=single([r for r in globals_ if re.fullmatch(pattern,r[2])],lambda s,g=good:s==g or (g=='no web-management' and s=='no web-management plaintext'))
    if detected:
        normalized=lambda s:re.sub(r'^[A-Za-z]+\.(?=16\.)','',s).lower()
        actual,wanted=normalized(detected),normalized(declared)
        if not (actual==wanted or wanted.startswith(actual+'.') or actual.startswith(wanted+'.')):raise ValueError('Configuration version conflicts with the declared OS version.')
    else:warnings.append('OS version is auditor-declared and must be verified against device evidence.')
    return dict(parser=VERSION,platform=platform,firmware=declared,detectedFirmware=detected,versionSource='Export marker and auditor declaration' if detected else 'Auditor declaration',values={},networkChecks=checks,warnings=warnings)

def evaluate(config,rule,asset):
    platform=rule.get('platform');reference=next((r for r in entry(platform)['rules'] if r['id']==rule['id']),None) if platform in PLATFORMS else None
    detail=dict(parser=VERSION,lines=[],reason='Explicit native configuration setting.',versionSource=config.get('versionSource','Unknown'))
    if not reference or any(rule.get(k)!=reference.get(k) for k in ('key','expected','engine','platform')):return 'Manual review','Changed policy requires a validated evaluator.',detail
    if config.get('platform')!=platform or platform_for(asset)!=platform or config.get('parser')!=VERSION:return 'Unable to assess','Missing compatible native evidence.',detail
    if config.get('firmware')!=asset.get('version'):return 'Unable to assess','Evidence and asset versions differ.',detail
    outcome=config.get('networkChecks',{}).get(rule['key'].split('.',1)[1],result())
    detail.update({k:v for k,v in outcome.items() if k not in ('status','observed')})
    return outcome['status'],outcome['observed'],detail
