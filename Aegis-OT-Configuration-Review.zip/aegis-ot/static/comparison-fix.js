/* Comparison diagnostics remain visible until the user resolves them. */
let comparisonError='';
const compareBeforeDiagnostics=comparison;
comparison=function(){
  const perDevice=a().assets.map(asset=>{
    const baselines=a().baselines.filter(b=>b.active&&baselineApplies(b,asset));
    const config=a().configs[asset.id];
    let message=!baselines.length?'No active matching baseline':!config?'Upload configuration evidence':config.parser&&!config.firmware?'Export has no firmware header':config.parser==='fortios-7.4/1.1'?'Re-upload evidence for the new parser':'Evidence attached';
    if(baselines.some(b=>b.source==='Vendor hardening guide'&&b.rules.some(r=>r.engine==='fortigate')))message='Legacy vendor approximation: select the new Fortinet Best Practices subset for corrected requirements';
    return `<tr><td>${esc(asset.name)}</td><td>${esc(asset.version)}${config?.firmware?' → '+esc(config.versionSource||'export')+' '+esc(config.firmware):''}</td><td>${esc(message)}</td><td>${baselines.map(b=>esc(b.name)).join('<br>')||'<button class="subtlebutton" data-view="baseline">Select baseline</button>'}</td></tr>`;
  }).join('');
  return `<div id="comparison-error" class="error" role="alert">${esc(comparisonError)}</div><section class="card"><div class="cardhead"><h2>Comparison readiness</h2></div><div class="tablewrap"><table><thead><tr><th>Device</th><th>Firmware</th><th>Evidence status</th><th>Active baseline</th></tr></thead><tbody>${perDevice}</tbody></table></div></section>`+compareBeforeDiagnostics();
};
const actionBeforeDiagnostics=action;
action=async function(name){
  if(!['run','retest'].includes(name))return actionBeforeDiagnostics(name);
  comparisonError='';
  try{return await actionBeforeDiagnostics(name)}catch(error){comparisonError=error.message;view='comparison';render();return toast('Comparison could not run. See the explanation above.');}
};
const rowsBeforeSourceLinks=tableRows;
tableRows=function(rows,controls=true){
  let html=rowsBeforeSourceLinks(rows,controls),cursor=0;
  for(const row of rows){
    const start=html.indexOf(`<strong>${esc(row.rule)}</strong>`,cursor);if(start<0)continue;
    const end=html.indexOf('</details>',start);
    if(end>=0&&/^https:\/\/(docs\.fortinet\.com|fortinetweb\.s3\.amazonaws\.com|sec\.cloudapps\.cisco\.com|arubanetworking\.hpe\.com|docs\.paloaltonetworks\.com|www\.juniper\.net)\//.test(row.reference||'')){
      const link=`<p><a href="${esc(row.reference)}" target="_blank" rel="noopener noreferrer">Open source requirement ↗</a></p><small>${esc(row.baselineSource||'')} · ${esc(row.version)}${row.firmware?' · Evidence firmware '+esc(row.firmware):''}</small>`;
      html=html.slice(0,end)+link+html.slice(end);
    }
    cursor=html.indexOf('</tr>',start)+5;
  }
  return html;
};
const renderBeforeBuild=render;
render=function(){renderBeforeBuild();const footer=$('.sidefoot');if(footer&&state?.build){const build=document.createElement('small');build.textContent='Build '+state.build;footer.append(build)}};
