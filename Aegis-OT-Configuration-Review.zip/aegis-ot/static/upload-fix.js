/* Installed vendor checks and explicit file-handling/navigation. */
catalogSelection={source:'Vendor hardening guide',product:'Firewall',vendor:'Fortinet',family:'FortiGate',productVersion:'7.4.x'};
const configsBeforeFix=configs;
configs=function(){
  let html=configsBeforeFix();
  html=html.replace('<label class="upload" style="margin-top:20px">','<div id="config-compatibility" aria-live="polite"></div><label id="config-drop" class="upload" style="margin-top:20px">');
  html=html.replace('<a href="/samples/firewall-config.json" download class="btn">','<a id="config-sample" href="/samples/firewall-config.json" download class="btn">');
  html=html.replace('</form>','<div id="config-error" class="error" role="alert" style="padding:0 24px"></div></form><div class="footeractions"><small>Attach evidence, then continue to run the selected checks.</small><button class="btn primary" data-view="comparison">Continue to comparison →</button></div>');
  return html;
};
const catalogBeforeFix=catalogView;
catalogView=function(){
  const html=catalogBeforeFix(),e=chosenEntry();
  const native=e?.rules?.some(r=>['fortigate','fortinet-best-practices','network-native'].includes(r.engine));
  const note=e?.installed?`<div class="notice"><div><b>Supported input:</b> ${native?'Use the selected platform’s native export. See the coverage directory for supported formats and versions.':'Normalized JSON or key=value settings. This baseline does not include a native vendor configuration parser.'}<br>${native?'Check coverage is shown in the selected profile; operational requirements remain manual.':'Imported manual requirements require human review.'}</div></div>`:'';
  const fix=e?.installed&&!a().assets.some(x=>entryMatches(e,x))?`<div class="notice warning"><div><b>Device details do not match this baseline.</b> Set vendor, product and version on the intended device. ${a().assets.filter(x=>x.product===e.product).map(x=>`<button class="btn" data-editasset="${esc(x.id)}">Update ${esc(x.name)}</button>`).join('')}</div></div>`:'';
  return note+fix+html;
};
const bindBeforeFix=bind;
bind=function(){
  bindBeforeFix();
  const form=$('#config-upload');if(!form)return;
  const input=$('#config-file'),zone=$('#config-drop'),source=form.elements.namedItem('asset');
  configFile=null;
  const showError=message=>{$('#config-error').textContent=message};
  const choose=file=>{
    configFile=null;$('#config-filelabel').textContent='';input.value='';
    if(!file)return;
    if(!/\.(json|txt|conf|cfg|xml|set)$/i.test(file.name))return showError('Use a supported .conf, .cfg, .txt, .set, .xml export, or flat .json for normalized checks.');
    if(!file.size||file.size>8*1024*1024)return showError('Select a non-empty file no larger than 8 MB.');
    configFile=file;$('#config-filelabel').textContent=file.name+' · '+Math.ceil(file.size/1024)+' KB';showError('');
  };
  input.onchange=e=>choose(e.target.files[0]);
  zone.ondragover=e=>{e.preventDefault();zone.classList.add('drag')};
  zone.ondragleave=()=>zone.classList.remove('drag');
  zone.ondrop=e=>{e.preventDefault();zone.classList.remove('drag');if(e.dataTransfer.files.length!==1)return showError('Drop one configuration file at a time.');choose(e.dataTransfer.files[0])};
  const compatibility=()=>{
    const asset=a().assets.find(x=>x.id===source.value),baselines=asset?a().baselines.filter(b=>b.active&&baselineApplies(b,asset)):[];
    const native=baselines.some(b=>b.rules.some(r=>['fortigate','fortinet-best-practices','network-native'].includes(r.engine)));
    $('#config-compatibility').innerHTML=baselines.length?`<p class="muted">Active baseline: ${baselines.map(b=>esc(b.name)+' v'+esc(b.version)).join('; ')}<br>${native?'Required: a native export for this platform, compatible with '+esc(asset.version):'Required for automated equality checks: normalized JSON or key=value settings.'}</p>`:'<p class="error">No active baseline matches this device. Select and activate a compatible baseline before comparison.</p>';
    $('#config-sample').href=native?'/samples/fortinet-best-practices-7.4.5.conf':'/samples/firewall-config.json';
    $('#config-sample').textContent=native?'Sample FortiGate 7.4.5 export':'Sample normalized configuration';
  };
  source.onchange=()=>{compatibility();networkSample(source.value)};compatibility();networkSample(source.value);
  form.onsubmit=async e=>{e.preventDefault();const button=form.querySelector('.primary');button.disabled=true;showError('');try{const payload=await readFile(configFile);await api('action',{action:'config',assessment:aid,asset:source.value,...payload});configFile=null;await refresh();toast('Configuration read and attached. Continue to comparison.')}catch(error){showError(error.message)}finally{if(button.isConnected)button.disabled=false}};
};
