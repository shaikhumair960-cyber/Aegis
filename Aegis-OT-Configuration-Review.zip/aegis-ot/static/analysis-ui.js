/* Separate assessment completeness from technical compliance. */
function analysisSummary(run){
  const rows=run?.rows||[],applicable=rows.filter(r=>r.status!=='Not applicable').length;
  const assessed=rows.filter(r=>['Pass','Fail'].includes(r.status)).length;
  return {applicable,assessed,coverage:applicable?Math.round(100*assessed/applicable):null,unknown:rows.filter(r=>r.status==='Unable to assess').length,manual:rows.filter(r=>r.status==='Manual review').length};
}
function analysisPanel(){
  const run=activeRun();if(!run)return '';
  const m=analysisSummary(run);
  return `<section class="card analysis-panel"><div class="cardhead"><div><h2>Analysis completeness</h2><p class="muted">Run ${esc(run.id)} · technical results and evidence gaps</p></div>${badge(m.unknown||m.manual?'Evidence review needed':'Applicable checks assessed',m.unknown||m.manual?'amber':'green')}</div><div class="cardbody"><div class="analysis-metrics"><div><strong>${m.coverage===null?'—':m.coverage+'%'}</strong><span>Assessment coverage</span><small>${m.assessed} conclusive / ${m.applicable} applicable checks</small></div><div><strong>${m.unknown}</strong><span>Unable to assess</span><small>Missing, unsupported, or unverified evidence</small></div><div><strong>${m.manual}</strong><span>Manual review</span><small>Auditor judgment or additional evidence required</small></div></div><p class="muted">Compliance measures Pass ÷ (Pass + Fail). Assessment coverage measures (Pass + Fail) ÷ applicable checks. Exceptions never convert failures into passes.</p><button class="btn" data-view="retest">View retest analysis</button></div></section>`;
}
const overviewBeforeAnalysis=overview;
overview=function(){return analysisPanel()+overviewBeforeAnalysis()};
const findingsBeforeAnalysis=findings;
findings=function(){return analysisPanel()+findingsBeforeAnalysis()};
const reportBeforeAnalysis=report;
report=function(){return analysisPanel()+reportBeforeAnalysis()};
const tableBeforeAnalysis=tableRows;
tableRows=function(rows,controls=true){
  let html=tableBeforeAnalysis(rows,controls),cursor=0;
  for(const r of rows){
    const snippets=(r.checkEvidence?.snippets||[]).map(s=>`<p class="mono">Line ${esc(s.line)} · ${esc(s.context)}<br>${r.checkEvidence?.parser?.startsWith('fortios')?'set ':''}${esc(s.setting)} ${esc(s.value)}</p>`).join('')+(r.checkEvidence?.path?`<p class="mono">XML path: ${esc(r.checkEvidence.path)}</p>`:'')+`<p>Version provenance: ${esc(r.versionSource||'Legacy / unspecified')}</p>`;
    const change=r.change?`<p><b>${esc(r.change.kind)}</b>${r.change.previousRun?` · previous: ${esc(r.change.previousStatus)}<br>${r.change.evidenceChanged?'Configuration content changed':'Configuration content unchanged'}`:''}</p>`:'';
    const needle=`<p class="mono">${esc(r.evidence)}</p>`;
    // Replace each unique row occurrence; duplicate evidence references are intentional.
    const start=html.indexOf(`<strong>${esc(r.rule)}</strong>`,cursor);
    if(start>=0){const index=html.indexOf(needle,start);if(index>=0)html=html.slice(0,index)+needle+snippets+change+html.slice(index+needle.length);cursor=html.indexOf('</tr>',start)+5}
  }
  return html;
};
retestDelta=function(){
  const current=a().runs.at(-1),rows=current.rows;
  if(!rows.some(r=>r.change))return '<div class="cardbody"><p>Legacy run: detailed change classifications become available after a new comparison.</p></div>';
  const removed=current.analysis?.removedChecks||[];
  return `<div class="cardbody"><h3>Latest retest analysis</h3><p class="muted">A requirement or parser change is reported separately from remediation. Removed checks are scope changes, not resolved findings. Unchanged content does not prove a fresh collection from the device.</p><div class="tablewrap"><table><thead><tr><th>Asset / rule</th><th>Change</th><th>Previous → current</th><th>Evidence content</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.asset)}<small>${esc(r.rule)}</small></td><td>${esc(r.change?.kind||'Not classified')}</td><td>${esc(r.change?.previousStatus||'—')} → ${esc(r.status)}<small>${esc(r.change?.previousObserved??'—')} → ${esc(r.observed)}</small></td><td>${r.change?.evidenceChanged?'Changed':'Unchanged'}</td></tr>`).join('')}</tbody></table></div>${removed.length?`<h3>Checks removed from scope</h3>${removed.map(r=>`<p>${esc(r.asset)} / ${esc(r.baseline)} / ${esc(r.rule)} — previous ${esc(r.status)}</p>`).join('')}`:''}</div>`;
};
const renderBeforeAnalysis=render;
render=function(){renderBeforeAnalysis();if(state&&!state.assessments.length&&editable()){const main=$('main'),button=document.createElement('button');button.className='btn primary';button.textContent='Create assessment';button.onclick=()=>action('create');main.append(button)}};
