/* A direct route from supported evidence to traceable results. */
let reviewDraft={file:null,payload:null,preview:null,device:'',auditorReference:'',error:'',busy:false};
let showReferenceCatalog=false;
const catalogBeforeSupportedOnly=catalogView;
catalogView=function(){
 const catalog=state.catalog,products=state.products;
 try{
  if(!showReferenceCatalog){state.catalog=catalog.filter(e=>e.installed);state.products=products.filter(p=>state.catalog.some(e=>e.vendor===p.vendor&&e.family===p.family&&e.product===p.product))}
  return `<div class="cardbody"><label class="checkbox"><input id="catalog-references" type="checkbox" ${showReferenceCatalog?'checked':''}>Show reference-only benchmarks and unsupported product listings</label><p class="muted">Installed requirements are shown by default. A catalog reference does not install checks or a configuration parser.</p></div>`+catalogBeforeSupportedOnly();
 }finally{state.catalog=catalog;state.products=products}
};
function guidedReview(){
 const d=reviewDraft,p=d.preview;
 return `<section class="card"><div class="cardhead"><div><h2>Review a configuration</h2><p class="muted">Offline review against documented requirements. Nothing is sent to the device.</p></div>${badge('MULTI-VENDOR REVIEW')}</div><div class="cardbody"><div class="notice"><div><b>Choose the actual platform and export format.</b><br>New adapters evaluate an initial Aegis management-policy subset. Missing settings remain unknown; vendor listings do not imply complete coverage.</div></div><p>1. Preview file → 2. Confirm baseline → 3. Review results and export</p><form id="guided-form"><div class="formgrid">${networkSelection(d)}${field('Device name','device','text',d.device,'required maxlength="120"')}${field('Auditor reference','auditorReference','text',d.auditorReference,'required maxlength="240"')}</div><label class="upload" id="guided-drop" style="margin-top:20px"><input id="guided-file" type="file" accept=".conf,.cfg,.txt,.xml,.set" ${d.busy?'disabled':''}><strong>Select configuration or drag one file here</strong><p>Maximum 8 MB · file stays within this local application</p></label><p id="guided-filename">${esc(d.file?.name||'No file selected')}</p><div id="guided-error" role="alert" class="error">${esc(d.error)}</div><button class="btn primary" id="guided-preview" type="submit" ${d.busy?'disabled':''}>${d.busy?'Reading…':'Preview supported checks'}</button></form>${p?`<section style="margin-top:24px"><h3>${esc(p.baseline.name)}</h3><p>Baseline ${esc(p.baseline.version)} · OS release <b>${esc(p.firmware)}</b> · ${esc(p.versionSource)}<br>${esc(p.source)} · ${esc(p.baseline.profile)}</p><a href="${esc(p.baseline.url)}" target="_blank" rel="noopener noreferrer">Source documentation ↗</a><p>${p.summary.evaluated} / ${p.summary.applicable} requirements assessable from this file. ${p.summary.counts['Unable to assess']} missing or ambiguous; ${p.summary.counts['Manual review']} need human evidence.</p>${p.warnings.map(w=>`<p class="notice warning">${esc(w)}</p>`).join('')}<details open><summary>Preview requirements and observed settings</summary><div class="tablewrap"><table><thead><tr><th>Rule</th><th>Requirement</th><th>Expected</th><th>Observed</th><th>Preliminary status</th></tr></thead><tbody>${p.rows.map(r=>`<tr><td>${esc(r.rule)}</td><td>${esc(r.title)}</td><td>${esc(r.expected)}</td><td>${esc(r.observed)}</td><td>${statusBadge(r.status)}</td></tr>`).join('')}</tbody></table></div></details><label class="checkbox" style="margin:20px 0"><input type="checkbox" id="guided-confirm" ${d.busy?'disabled':''}>I reviewed this baseline and its limitations and confirm it for this assessment.</label><button class="btn primary" id="guided-run" ${d.busy?'disabled':''}>Create assessment & run comparison</button></section>`:''}</div></section>`;
}
function openGuidedReview(){reviewDraft={file:null,payload:null,preview:null,device:'',auditorReference:'',error:'',busy:false};view='guided';render()}
const overviewBeforeGuided=overview;
overview=function(){return `<section class="card" style="margin-bottom:24px"><div class="cardbody"><h2>Configuration review, with evidence</h2><p>Upload a supported network device export, preview a documented baseline, and get explainable findings. An assessment is created automatically after confirmation.</p><button class="btn primary" id="open-guided" ${!editable()?'disabled':''}>Review configuration</button><p class="muted">Native adapters: FortiGate · Cisco IOS/IOS XE · Aruba AOS-S · Palo Alto PAN-OS XML · Juniper Junos set format. Review the coverage directory for formats and limitations.</p></div></section>`+overviewBeforeGuided()};
const contentBeforeGuided=content;
content=function(){return view==='guided'?guidedReview():contentBeforeGuided()};
const workflowBeforeGuided=workflow;
workflow=function(){return view==='guided'?'':workflowBeforeGuided()};
const bindBeforeGuided=bind;
bind=function(){
 if(state?.assessments.length)bindBeforeGuided();
 if($('#open-guided'))$('#open-guided').onclick=openGuidedReview;
 if($('#catalog-references'))$('#catalog-references').onchange=e=>{showReferenceCatalog=e.target.checked;catalogEntryId='';render()};
 const form=$('#guided-form');if(!form)return;
 const capture=()=>{reviewDraft.device=form.elements.namedItem('device').value;reviewDraft.auditorReference=form.elements.namedItem('auditorReference').value;reviewDraft.platform=form.elements.namedItem('platform').value;reviewDraft.osVersion=form.elements.namedItem('osVersion').value};
 const choose=file=>{if(reviewDraft.busy)return;capture();reviewDraft.file=file;reviewDraft.preview=null;reviewDraft.payload=null;reviewDraft.error='';if(file&&(!/\.(conf|cfg|txt|xml|set)$/i.test(file.name)||!file.size||file.size>8*1024*1024)){reviewDraft.file=null;reviewDraft.error='Select a supported non-empty text or XML export up to 8 MB.'}render()};
 $('#guided-file').onchange=e=>choose(e.target.files[0]);
 $('#guided-drop').ondragover=e=>e.preventDefault();
 $('#guided-drop').ondrop=e=>{e.preventDefault();if(!reviewDraft.busy){if(e.dataTransfer.files.length!==1){$('#guided-error').textContent='Drop exactly one file.';return}choose(e.dataTransfer.files[0])}};
 form.onsubmit=async e=>{e.preventDefault();if(reviewDraft.busy)return;capture();reviewDraft.busy=true;reviewDraft.error='';$('#guided-preview').disabled=true;$('#guided-file').disabled=true;try{const payload=await readFile(reviewDraft.file);reviewDraft.payload=payload;reviewDraft.preview=await api('config-preview',{...payload,platform:reviewDraft.platform,osVersion:reviewDraft.osVersion})}catch(error){reviewDraft.preview=null;reviewDraft.error=error.message}finally{reviewDraft.busy=false;render()}};
 if($('#guided-run'))$('#guided-run').onclick=async()=>{
   capture();if(!form.reportValidity())return;
   if(!$('#guided-confirm').checked){$('#guided-error').textContent='Review the requirements and confirm the baseline first.';return}
   const button=$('#guided-run');button.disabled=true;reviewDraft.busy=true;
   try{const out=await api('config-review',{...reviewDraft.payload,device:reviewDraft.device,auditorReference:reviewDraft.auditorReference,previewHash:reviewDraft.preview.hash,previewToken:reviewDraft.preview.previewToken,platform:reviewDraft.platform,osVersion:reviewDraft.osVersion,confirmed:true});aid=out.id;runIndex=-1;view='findings';reviewDraft.file=null;reviewDraft.payload=null;await refresh();toast('Comparison complete. Review findings and evidence gaps before exporting.')}catch(error){reviewDraft.error=error.message;reviewDraft.busy=false;render()}
 };
};
const renderBeforeGuided=render;
render=function(){
 if(state&&!state.assessments.length&&view==='guided'){$('#app').innerHTML=`<main style="max-width:1100px;margin:30px auto;padding:20px">${guidedReview()}</main>`;bind();return}
 renderBeforeGuided();
 if(state?.user.localWorkspace){$$('[data-action="logout"],#empty-signout').forEach(el=>el.remove());if($('.role'))$('.role').textContent='Local access · sign-in disabled'}
 if(state&&!state.assessments.length&&editable()){const button=document.createElement('button');button.className='btn primary';button.textContent='Review configuration';button.onclick=openGuidedReview;$('main').append(button)}
 if(view==='guided'&&$('h1'))$('h1').textContent='Guided configuration review';
};

