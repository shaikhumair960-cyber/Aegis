"""Integration checks against an isolated temporary database, never the user's data."""
import base64, http.cookiejar, io, json, tempfile, threading, unittest
from pathlib import Path
from urllib.request import build_opener, HTTPCookieProcessor, Request
from urllib.error import HTTPError
import server

class WorkflowTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(); server.DB=Path(cls.tmp.name)/'data'/'audit.db'; server.init()
        cls.http=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        cls.url='http://127.0.0.1:'+str(cls.http.server_port)
        threading.Thread(target=cls.http.serve_forever,daemon=True).start()
        cls.passwords=json.loads((server.DB.parent/'local-credentials.json').read_text())
    @classmethod
    def tearDownClass(cls): cls.http.shutdown(); cls.http.server_close(); cls.tmp.cleanup()
    def client(self,role):
        client=build_opener(HTTPCookieProcessor(http.cookiejar.CookieJar()))
        self.request(client,'login',{'name':role,'password':self.passwords[role]})
        state=self.request(client,'state')[1]
        return client,state['user']['csrf']
    def request(self,client,path,data=None,csrf=None):
        headers={'Content-Type':'application/json'}
        if csrf: headers['X-CSRF-Token']=csrf
        req=Request(self.url+'/api/'+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
        try:
            with client.open(req) as r: return r.status,json.load(r)
        except HTTPError as e: return e.code,json.load(e)
    def test_complete_workflow_and_authorization(self):
        client,csrf=self.client('admin')
        def action(action,**d): return self.request(client,'action',dict(action=action,assessment='OT-2026-001',**d),csrf)
        def current(): return self.request(client,'state')[1]['assessments'][0]
        asset=current()['assets'][0]['id']
        self.assertEqual(action('run')[0],200)
        self.assertTrue(all(r['status']=='Unable to assess' for r in current()['runs'][-1]['rows']))
        raw=b'id,title,key,expected\nUP-1,Disable Telnet,telnet_enabled,true\nUP-2,Manual check,,\n'
        payload=dict(filename='test.csv',data=base64.b64encode(raw).decode(),name='Test baseline',version='1',approval='TEST-1',date='2026-01-01',devices='Firewall',group='Perimeter')
        self.assertEqual(action('upload_baseline',**payload)[0],200)
        b=current()['baselines'][-1]
        self.assertTrue(all(r['mode']=='manual' for r in b['rules']))
        self.assertEqual(action('activate',baseline=b['id'],confirmed=False)[0],400)
        b['rules'][0]['mode']='automated'
        self.assertEqual(action('rules',baseline=b['id'],rules=b['rules'])[0],200)
        self.assertEqual(action('activate',baseline=b['id'],confirmed=True)[0],200)
        self.assertEqual(action('rules',baseline=b['id'],rules=b['rules'])[0],400)
        self.assertEqual(action('run')[0],400) # conflicting expected setting
        for conflict in server.conflicts(current()):
            self.assertEqual(action('precedence',key=conflict['key'],choice=b['id']+'|UP-1')[0],200)
        self.assertEqual(action('config',asset=asset,filename='config.json',data=base64.b64encode(b'{"telnet_enabled":false,"syslog_enabled":true}').decode())[0],200)
        self.assertEqual(action('run')[0],200)
        initial=current()['runs'][-1]
        statuses={r['status'] for r in initial['rows']}
        self.assertTrue({'Fail','Pass','Unable to assess','Manual review','Not applicable'}<=statuses)
        self.assertEqual(action('run',retest=True)[0],400)
        self.assertEqual(action('config',asset=asset,filename='retest.json',data=base64.b64encode(b'{"telnet_enabled":true,"syslog_enabled":true}').decode())[0],200)
        self.assertEqual(action('run',retest=True)[0],200)
        updated=current()
        self.assertEqual(updated['runs'][-2],initial)
        row=next(r for r in updated['runs'][-1]['rows'] if r['rule']=='UP-1' and r['assetId']==asset)
        self.assertEqual(row['status'],'Pass')
        reviewer,token=self.client('reviewer')
        self.assertEqual(self.request(reviewer,'action',dict(action='run',assessment=updated['id']),token)[0],403)
        self.assertEqual(self.request(reviewer,'action',dict(action='validate',assessment=updated['id'],finding=row['id'],review='Confirmed',note='Reviewed evidence'),token)[0],200)
        auditor,token=self.client('auditor')
        self.assertEqual(self.request(auditor,'action',dict(action='validate',assessment=updated['id'],finding=row['id'],review='Confirmed',note='No'),token)[0],403)
        self.assertEqual(self.request(client,'action',dict(action='run',assessment=updated['id']))[0],400)
        self.assertEqual(action('exception',finding=row['id'],justification='Operational constraint',approval='EX-1',expiry='2020-01-01')[0],400)
        self.assertEqual(action('exception',finding=row['id'],justification='Operational constraint',approval='EX-1',expiry='2099-01-01')[0],200)
        self.assertEqual(current()['runs'][-1]['rows'][0]['status'],updated['runs'][-1]['rows'][0]['status'])
        self.assertEqual(action('config',asset=asset,filename='bad.exe',data='eA==')[0],400)
    def test_document_parsers(self):
        from openpyxl import Workbook
        from docx import Document
        from pypdf import PdfWriter
        w=Workbook(); w.active.append(['id','title','key','expected']); w.active.append(['X-1','Disable Telnet','telnet_enabled','false']); buf=io.BytesIO();w.save(buf)
        self.assertEqual(server.extract('.xlsx',buf.getvalue())[0]['mode'],'manual')
        d=Document();d.add_paragraph('Security events must be sent to the approved collector.');buf=io.BytesIO();d.save(buf)
        self.assertEqual(len(server.extract('.docx',buf.getvalue())),1)
        p=PdfWriter();p.add_blank_page(400,400);buf=io.BytesIO();p.write(buf)
        with self.assertRaises(ValueError): server.extract('.pdf',buf.getvalue())

if __name__=='__main__': unittest.main(verbosity=2)
