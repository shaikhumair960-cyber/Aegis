"""Conservative offline FortiOS 7.4 parser and original Aegis checks (not CIS)."""
import re, shlex
PARSER_VERSION='fortios-7.4/1.2'
REFERENCE='https://docs.fortinet.com/document/fortigate/7.4.0/cli-reference/001620/config-system-global'
CHECKS=[
 ('FG-001','Restrict idle administrator sessions','fg.idle_timeout','1–15 minutes','High','Set admintimeout to an approved value between 1 and 15 minutes.'),
 ('FG-002','Enable strong administrative cryptography','fg.strong_crypto','enable','High','Enable strong-crypto after confirming management client compatibility.'),
 ('FG-003','Restrict administrative HTTPS to TLS 1.2 or 1.3','fg.admin_tls','TLS 1.2 / TLS 1.3 only','High','Allow only tlsv1-2 and/or tlsv1-3 for administrative HTTPS.'),
 ('FG-004','Bound failed administrator login attempts','fg.lockout_threshold','1–5 attempts','Medium','Set admin-lockout-threshold between 1 and 5, per approved policy.'),
 ('FG-005','Retain administrator lockout for at least 60 seconds','fg.lockout_duration','60 seconds or longer','Medium','Set admin-lockout-duration to at least 60 seconds.'),
 ('FG-006','Disable HTTP and Telnet management on interfaces','fg.cleartext_management','No HTTP / Telnet management','High','Remove http and telnet from interface allowaccess; retain approved secure access.'),
]
def catalog_entry():
    return dict(id='aegis-fortios74',name='Aegis FortiOS 7.4 administrative hardening',source='Internal baseline',product='Firewall',vendor='Fortinet',family='FortiGate',os='FortiOS',productVersion='7.4.x',version='1.0.0',profile='Administrative access · 6 checks',installed=True,license='Original Aegis rules · not a CIS certification or complete device assessment',rules=[dict(id=i,title=t,key=k,expected=e,mode='automated',applicable=True,mapping='Fortinet CLI reference; organization policy',engine='fortigate',severity=s,remediation=r,reference=REFERENCE) for i,t,k,e,s,r in CHECKS])

def parse(text):
    """Never execute commands. Reject incomplete structure; never infer omitted defaults."""
    if len(text)>8*1024*1024:raise ValueError('Configuration exceeds 8 MB.')
    stack=[];records={};sections=set();version=None;warnings=[]
    pending='';start=0
    for number,line in enumerate(text.splitlines(),1):
        if pending:line=pending+'\n'+line
        else:start=number
        stripped=line.strip()
        if stripped.startswith('#config-version='):
            match=re.search(r'-(\d+\.\d+\.\d+)-',stripped)
            if match:
                if version and version!=match.group(1):raise ValueError('Conflicting firmware headers in export.')
                version=match.group(1)
        if not stripped or stripped.startswith('#'):continue
        try:tokens=shlex.split(stripped,posix=True)
        except ValueError as error:
            if 'No closing quotation' in str(error):pending=line;continue
            raise ValueError(f'Malformed quoted value at line {start}.') from error
        pending=''
        if not tokens:continue
        command=tokens[0]
        if command=='config' and len(tokens)>1:
            stack.append(('config',' '.join(tokens[1:])));sections.add(tuple(stack))
        elif command=='edit' and len(tokens)==2 and stack and stack[-1][0]=='config':stack.append(('edit',tokens[1]));sections.add(tuple(stack))
        elif command in ['set','unset'] and len(tokens)>=2 and stack:
            if command=='set' and len(tokens)<3:raise ValueError(f'Missing setting value at line {number}.')
            path=tuple(stack)
            if (path,tokens[1]) in records:raise ValueError(f'Duplicate setting at line {start}; supply one unambiguous export.')
            records[(path,tokens[1])]=dict(values=tokens[2:] if command=='set' else None,line=start,command=command)
        elif command=='next' and len(tokens)==1 and stack and stack[-1][0]=='edit':stack.pop()
        elif command=='end' and len(tokens)==1 and stack and stack[-1][0]=='config':stack.pop()
        else:raise ValueError(f'Unsupported or malformed configuration command at line {number}. Export show full-configuration; do not upload CLI scripts.')
    if pending:raise ValueError(f'Unterminated quoted value at line {start}.')
    if stack:raise ValueError('Truncated configuration: unclosed config/edit block.')
    if not sections:raise ValueError('No FortiOS configuration blocks found.')
    if not version:warnings.append('Firmware not in export header; asset version must be confirmed by auditor.')
    if any(('config','vdom') in p for p in sections):warnings.append('VDOM configuration detected. Context-dependent checks require manual review.')
    result={};evidence={};outcomes={}
    def record(key,observed,status,lines,reason):
        snippets=[]
        for (path,setting),entry in records.items():
            if entry['line'] in lines:
                snippets.append(dict(line=entry['line'],context=' / '.join(p[1] for p in path),setting=setting,value=' '.join(entry['values'] or [])))
        result[key]=observed;outcomes[key]=status;evidence[key]=dict(lines=sorted(set(lines)),reason=reason,parser=PARSER_VERSION,snippets=snippets)
    globalpaths=[p for p in sections if p==(('config','system global'),) or p==(('config','global'),('config','system global'))]
    settings=[('fg.idle_timeout','admintimeout',lambda x:len(x)==1 and x[0].isdigit() and 1<=int(x[0])<=15),('fg.strong_crypto','strong-crypto',lambda x:x==['enable']),('fg.admin_tls','admin-https-ssl-versions',lambda x:bool(x) and set(x)<=set(['tlsv1-2','tlsv1-3'])),('fg.lockout_threshold','admin-lockout-threshold',lambda x:len(x)==1 and x[0].isdigit() and 1<=int(x[0])<=5),('fg.lockout_duration','admin-lockout-duration',lambda x:len(x)==1 and x[0].isdigit() and int(x[0])>=60)]
    for key,setting,predicate in settings:
        rec=records.get((globalpaths[0],setting)) if len(globalpaths)==1 else None
        if not rec or rec['values'] is None:record(key,'Not explicit in export','Unable to assess',[],'Setting omitted, unset, or global context ambiguous. No defaults inferred.');continue
        vals=rec['values'];record(key,' '.join(vals),'Pass' if predicate(vals) else 'Fail',[rec['line']],f'Explicit system global / {setting}; evaluated against Aegis policy.')
    interfaces=[p for p in sections if p[-1][0]=='edit' and len(p)>1 and p[-2]==('config','system interface')]
    lines=[];insecure=[];unknown=[]
    for path in interfaces:
        rec=records.get((path,'allowaccess'))
        if not rec or rec['values'] is None:unknown.append(path[-1][1]);continue
        lines.append(rec['line'])
        if set(rec['values'])&{'http','telnet'}:insecure.append(path[-1][1])
    vdom=any(('config','vdom') in p for p in sections)
    status='Fail' if insecure else 'Manual review' if vdom else 'Unable to assess' if not interfaces or unknown else 'Pass'
    # Avoid dumping arbitrary sensitive configuration; only interface names and checked values survive.
    record('fg.cleartext_management','Insecure interfaces: '+', '.join(insecure) if insecure else 'No explicit insecure management found',status,lines,'Review all interface contexts. Omitted allowaccess is unknown. '+('Missing explicit setting on: '+', '.join(unknown) if unknown else ''))
    allowed={'admintimeout','admin-sport','admin-ssh-port','admin-https-redirect','admin-host','strong-crypto','ssl-static-key-ciphers','dh-params'}
    bp={'system global':{},'interfaces':[],'vdom':vdom}
    def safe_record(path,setting):
        rec=records.get((path,setting))
        return dict(setting=setting,context=' / '.join(p[1] for p in path),values=rec['values'] if rec else None,line=rec['line'] if rec else None)
    if len(globalpaths)==1:
        for setting in allowed:
            if (globalpaths[0],setting) in records:bp['system global'][setting]=safe_record(globalpaths[0],setting)
    for path in interfaces:
        bp['interfaces'].append(safe_record(path,'allowaccess'))
        bp['interfaces'].append(safe_record(path+(('config','ipv6'),),'ip6-allowaccess'))
    return dict(parser=PARSER_VERSION,firmware=version,values=result,outcomes=outcomes,checks=evidence,warnings=warnings,bestPracticeEvidence=bp)

def firmware_error(config,asset):
    if config.get('parser')!=PARSER_VERSION:return 'Re-upload the native FortiOS export to use the current parser.'
    actual=config.get('firmware') or '';declared=asset.get('version','').strip()
    if not re.fullmatch(r'7\.4\.\d+',actual):return 'A FortiOS 7.4 patch version is required in the export header.'
    if declared not in ['7.4','7.4.x',actual]:return 'Export firmware differs from the selected device version.'
    return None

def evaluate(config,rule,asset):
    reason=firmware_error(config,asset)
    if reason:return 'Unable to assess',reason,dict(reason=reason,parser=PARSER_VERSION,lines=[])
    key=rule['key']
    expected=next((e for _,_,k,e,_,_ in CHECKS if k==key),None)
    if rule['expected']!=expected:return 'Manual review','Custom threshold requires a separately validated check.',{}
    return config['outcomes'].get(key,'Unable to assess'),config['values'].get(key,'No result'),config.get('checks',{}).get(key,{})
