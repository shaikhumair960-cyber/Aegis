"""Flask transport adapter. All authorization stays in the shared handler."""
import io, json, os
from flask import Flask,request,Response

def create_app(core=None):
    if core is None:import server as core
    app=Flask(__name__,static_folder=None)
    app.config.update(MAX_CONTENT_LENGTH=12*1024*1024)
    class Adapter(core.Handler):
        def send_response(self,code,message=None):self.status=code
        def send_header(self,key,value):self.response_headers.append((key,value))
        def end_headers(self):pass
    @app.route('/',defaults={'path':''},methods=['GET','POST'])
    @app.route('/<path:path>',methods=['GET','POST'])
    def dispatch(path):
        h=Adapter.__new__(Adapter);h.path=request.full_path.rstrip('?');h.headers=request.headers;h.rfile=io.BytesIO(request.get_data());h.wfile=io.BytesIO();h.client_address=(request.remote_addr or 'unknown',0);h.response_headers=[];h.status=200
        h.do_POST() if request.method=='POST' else h.do_GET()
        return Response(h.wfile.getvalue(),status=h.status,headers=h.response_headers)
    @app.errorhandler(413)
    def too_large(error):return {'error':'Upload exceeds 12 MB request limit.'},413
    return app

def serve(core):
    from waitress import serve as run
    origin=os.getenv('AEGIS_PUBLIC_URL','http://127.0.0.1:5000').rstrip('/')
    if os.getenv('AEGIS_PRODUCTION')=='1' and not origin.startswith('https://'):raise SystemExit('Production requires HTTPS AEGIS_PUBLIC_URL and a TLS reverse proxy.')
    print('Aegis OT · Waitress · '+origin,flush=True)
    # Reuse the exclusive socket already reserved by server.py.
    run(create_app(core),sockets=[core.httpd.socket],threads=8,max_request_body_size=12*1024*1024,channel_timeout=60,expose_tracebacks=False,clear_untrusted_proxy_headers=True)
