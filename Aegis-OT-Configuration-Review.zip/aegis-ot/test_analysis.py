import copy, unittest
from analysis import annotate,summarize
from fortigate import parse,evaluate,catalog_entry
from pathlib import Path

FIXTURE=(Path(__file__).parent/'samples'/'fortigate-7.4.5.conf').read_text()

class AnalysisTests(unittest.TestCase):
    def run_fixture(self,status='Fail',observed='telnet',version='1.0',digest='one'):
        return dict(id='run',baselines=[dict(id='baseline',rules=[dict(id='rule',expected='ssh')])],configs={'asset':{'hash':digest}},rows=[dict(assetId='asset',asset='Firewall',baselineId='baseline',baseline='Original',version=version,rule='rule',expected='ssh',observed=observed,status=status)])
    def test_coverage_not_inflated_by_unknown_or_na(self):
        result=summarize([{'status':s} for s in ['Pass','Fail','Unable to assess','Manual review','Not applicable']])
        self.assertEqual(result['coverage'],50);self.assertEqual(result['compliance'],50)
        self.assertIsNone(summarize([{'status':'Not applicable'}])['coverage'])
        self.assertIsNone(summarize([{'status':'Unable to assess'}])['compliance'])
    def test_resolution_and_reopened_failure(self):
        first=annotate(self.run_fixture(),[])
        second=annotate(self.run_fixture('Pass','ssh',digest='two'),[first])
        third=annotate(self.run_fixture(digest='three'),[first,second])
        self.assertEqual(second['rows'][0]['change']['kind'],'Resolved')
        self.assertEqual(third['rows'][0]['change']['kind'],'Reopened')
        self.assertTrue(second['rows'][0]['change']['evidenceChanged'])
    def test_requirement_change_is_not_resolution(self):
        first=annotate(self.run_fixture(),[])
        second=annotate(self.run_fixture('Pass','ssh',version='2.0'),[first])
        self.assertEqual(second['rows'][0]['change']['kind'],'Requirement changed')
    def test_unchanged_evidence_and_removed_check(self):
        first=annotate(self.run_fixture(),[])
        second=annotate(self.run_fixture(),[first])
        self.assertFalse(second['rows'][0]['change']['evidenceChanged'])
        self.assertEqual(second['rows'][0]['change']['kind'],'Recurring failure')
        third=self.run_fixture();third['rows']=[];annotate(third,[second])
        self.assertEqual(len(third['analysis']['removedChecks']),1)
    def test_missing_firmware_cannot_pass(self):
        config=parse('\n'.join(line for line in FIXTURE.splitlines() if not line.startswith('#config-version=')))
        for rule in catalog_entry()['rules']:
            self.assertEqual(evaluate(config,rule,{'version':'7.4.5'})[0],'Unable to assess')
    def test_multiline_certificates_and_escaped_values(self):
        config=parse(FIXTURE+'\nconfig vpn certificate local\n edit "test"\n set certificate "-----BEGIN CERTIFICATE-----\nSAMPLE\n-----END CERTIFICATE-----"\n next\nend\n')
        self.assertEqual(config['outcomes']['fg.idle_timeout'],'Pass')
        self.assertNotIn('SAMPLE',str(config))
    def test_duplicate_setting_and_conflicting_headers_rejected(self):
        for value in [FIXTURE.replace('set admintimeout 10','set admintimeout 10\n set admintimeout 20'),FIXTURE+'\n#config-version=FGT60F-7.4.6-FW-build1']:
            with self.assertRaises(ValueError):parse(value)
    def test_source_lines_survive_multiline_values(self):
        prefix='config vpn certificate local\n edit test\n set certificate "line1\nline2"\n next\nend\n'
        data=parse(prefix+FIXTURE)
        original=parse(FIXTURE)
        self.assertEqual(data['checks']['fg.idle_timeout']['lines'][0],original['checks']['fg.idle_timeout']['lines'][0]+6)

if __name__=='__main__':unittest.main()
