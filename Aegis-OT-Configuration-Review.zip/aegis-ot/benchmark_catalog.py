"""Product directory and public benchmark metadata; no CIS requirement text."""
PRODUCTS = [
    dict(product='Firewall',vendor='Fortinet',family='FortiGate',os='FortiOS',versions=['7.4.x','7.0.x']),
    dict(product='Firewall',vendor='Palo Alto Networks',family='PA-Series / VM-Series',os='PAN-OS',versions=['11.x','10.x']),
    dict(product='Firewall',vendor='Cisco',family='ASA',os='ASA Software',versions=['9.x']),
    dict(product='Firewall',vendor='Cisco',family='Secure Firewall',os='Firepower Threat Defense',versions=[]),
    dict(product='Firewall',vendor='Check Point',family='Quantum Security Gateway',os='Gaia',versions=[]),
    dict(product='Firewall',vendor='Sophos',family='XGS / XG Firewall',os='SFOS',versions=[]),
    dict(product='Firewall',vendor='Juniper Networks',family='SRX Series',os='Junos OS',versions=[]),
    dict(product='Switch',vendor='Cisco',family='Catalyst (IOS XE)',os='IOS XE',versions=['17.x','16.x']),
    dict(product='Switch',vendor='Cisco',family='Catalyst (IOS)',os='IOS',versions=['17.x','16.x']),
    dict(product='Switch',vendor='Cisco',family='Nexus',os='NX-OS',versions=[]),
    dict(product='Switch',vendor='HPE / Aruba (HP)',family='Aruba CX',os='AOS-CX',versions=[]),
    dict(product='Switch',vendor='HPE / Aruba (HP)',family='Aruba / ProCurve',os='ArubaOS-Switch',versions=[]),
    dict(product='Switch',vendor='HPE / Aruba (HP)',family='FlexNetwork',os='Comware',versions=[]),
    dict(product='Switch',vendor='Juniper Networks',family='EX / QFX Series',os='Junos OS',versions=[]),
    dict(product='Switch',vendor='Arista',family='Data Center / Campus Switch',os='EOS',versions=[]),
    dict(product='Switch',vendor='Dell',family='PowerSwitch',os='SmartFabric OS10',versions=[]),
    dict(product='Windows Server',vendor='Microsoft',family='Windows Server',os='Windows Server',versions=['2025','2022','2019','2016']),
    dict(product='Linux Server',vendor='Red Hat',family='Enterprise Linux',os='RHEL',versions=['9','8']),
    dict(product='Linux Server',vendor='Canonical',family='Ubuntu Server',os='Ubuntu',versions=['24.04','22.04']),
]
PRODUCTS.extend([dict(product='Router',vendor='Cisco',family='IOS / IOS XE Router',os='IOS / IOS XE',versions=['17.9','16.12','15.2']),dict(product='Router',vendor='Juniper Networks',family='MX Series',os='Junos OS',versions=['24.2R1'])])
REFERENCES=[]
def reference(pid, version, release, slug, title):
    p=PRODUCTS[pid]
    REFERENCES.append(dict(id='cis-'+str(len(REFERENCES)+1),source='CIS',product=p['product'],vendor=p['vendor'],family=p['family'],os=p['os'],productVersion=version,version=release,profile='',name=title,installed=False,rules=[],license='Authorized content import required; confirm applicable usage rights.',url='https://www.cisecurity.org/benchmark/'+slug,verified='2026-09-15'))
reference(0,'7.4.x','1.0.1','fortinet','CIS FortiGate 7.4.x')
reference(0,'7.0.x','1.4.0','fortinet','CIS Fortigate 7.0.x')
reference(1,'11.x','1.2.0','palo_alto_networks','CIS Palo Alto Firewall 11')
reference(1,'10.x','1.3.0','palo_alto_networks','CIS Palo Alto Firewall 10 FINAL RELEASE')
reference(1,'10.x','1.2.0','palo_alto_networks','CIS Palo Alto Firewall 10')
reference(2,'9.x','1.1.0','cisco','CIS Cisco ASA 9.x Firewall')
reference(3,'','1.0.0','cisco','CIS Cisco Firepower Threat Defense')
reference(7,'17.x','2.2.1','cisco','CIS Cisco IOS XE 17.x')
reference(7,'16.x','2.2.0','cisco','CIS Cisco IOS XE 16.x')
reference(8,'17.x','2.0.0','cisco','CIS Cisco IOS 17.x')
reference(8,'16.x','2.0.0','cisco','CIS Cisco IOS 16')
reference(9,'','1.2.0','cisco','CIS Cisco NX-OS')
reference(10,'','1.0.1','aruba','CIS HPE Aruba Networking CX Switch')

def version_matches(scope, actual):
    """Only explicit .x family scope permits prefix matching. Empty is unscoped."""
    if not scope: return True
    scope,actual=scope.strip().lower(),actual.strip().lower()
    if scope.endswith('.x'):
        prefix=scope[:-2]
        return actual==prefix or actual.startswith(prefix+'.')
    return scope==actual

def applies(b,asset):
    native=next((r.get('platform') for r in b.get('rules',[]) if r.get('engine')=='network-native'),None)
    if native:
        from network_devices import supported,platform_for,PLATFORMS
        if native not in PLATFORMS or platform_for(asset)!=native or not supported(asset.get('version',''),native):return False
    return (b['group']==asset['group'] and b['devices']==asset['product']
        and (not b.get('vendor') or b['vendor']==asset.get('vendor'))
        and (not b.get('family') or b['family']==asset.get('family'))
        and version_matches(b.get('productVersion',''),asset['version']))

def catalog_matches(e,asset):
    return applies(dict(e,group=asset['group'],devices=e['product']),asset)
