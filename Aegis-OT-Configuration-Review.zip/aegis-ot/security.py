"""Encryption, bounded local login throttling, and audit-chain primitives."""
import base64, ctypes, hashlib, hmac, json, os, secrets, threading, time
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

def dpapi(data,unprotect=False):
    class Blob(ctypes.Structure):_fields_=[('size',ctypes.c_ulong),('data',ctypes.POINTER(ctypes.c_ubyte))]
    buffer=ctypes.create_string_buffer(data);source=Blob(len(data),ctypes.cast(buffer,ctypes.POINTER(ctypes.c_ubyte)));target=Blob()
    crypt=ctypes.windll.crypt32;func=crypt.CryptUnprotectData if unprotect else crypt.CryptProtectData
    if not func(ctypes.byref(source),None,None,None,None,1,ctypes.byref(target)):raise RuntimeError('Cannot access this Windows-user protected encryption key.')
    try:return ctypes.string_at(target.data,target.size)
    finally:
        free=ctypes.windll.kernel32.LocalFree;free.argtypes=[ctypes.c_void_p];free.restype=ctypes.c_void_p;free(target.data)

class Vault:
    def __init__(self,directory):
        root=Path(directory);root.mkdir(parents=True,exist_ok=True)
        external=os.getenv('AEGIS_MASTER_KEY')
        if external:
            self.key=base64.b64decode(external,validate=True)
            if len(self.key)!=32:raise ValueError('AEGIS_MASTER_KEY must encode 32 random bytes.')
        else:
            if os.getenv('AEGIS_PRODUCTION')=='1':raise ValueError('Production requires an externally managed AEGIS_MASTER_KEY.')
            path=root/'vault.key'
            if path.exists():
                saved=path.read_bytes();self.key=dpapi(saved[4:],True) if saved.startswith(b'DP1:') else saved[4:]
            else:
                self.key=secrets.token_bytes(32);saved=b'DP1:'+dpapi(self.key) if os.name=='nt' else b'RAW:'+self.key
                fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
                with os.fdopen(fd,'wb') as f:f.write(saved)
            if len(self.key)!=32:raise ValueError('Invalid encryption key file.')
        self.aes=AESGCM(self.key)
    def seal(self,raw,context):
        nonce=secrets.token_bytes(12);return nonce+self.aes.encrypt(nonce,raw,context.encode())
    def open(self,blob,context):return self.aes.decrypt(blob[:12],blob[12:],context.encode())
    def encode(self,value,context):return 'ENC1:'+base64.b64encode(self.seal(json.dumps(value).encode(),context)).decode()
    def decode(self,value,context):return json.loads(self.open(base64.b64decode(value[5:]),context)) if value.startswith('ENC1:') else json.loads(value)
    def mac(self,value):return hmac.new(self.key,value.encode(),hashlib.sha256).hexdigest()

class LoginLimiter:
    def __init__(self):self.lock=threading.Lock();self.entries={}
    def allowed(self,ip,name):
        with self.lock:
            now=time.monotonic();self.entries={k:[t for t in v if now-t<900] for k,v in self.entries.items() if any(now-t<900 for t in v)}
            return len(self.entries)<10000 and len(self.entries.get('account:'+name,[]))<5 and len(self.entries.get('ip:'+ip,[]))<30
    def failed(self,ip,name):
        with self.lock:
            if len(self.entries)>=10000:return
            for key in ['account:'+name,'ip:'+ip]:self.entries.setdefault(key,[]).append(time.monotonic())
    def success(self,ip,name):
        with self.lock:self.entries.pop('account:'+name,None)

LIMITER=LoginLimiter()
