"""Evidence coverage and comparable retest changes; no inferred operational risk."""
import hashlib,json

def summarize(rows):
    counts={s:sum(r['status']==s for r in rows) for s in ['Pass','Fail','Manual review','Unable to assess','Not applicable']}
    applicable=len(rows)-counts['Not applicable'];evaluated=counts['Pass']+counts['Fail']
    return dict(counts=counts,applicable=applicable,evaluated=evaluated,
                compliance=round(100*counts['Pass']/evaluated) if evaluated else None,
                coverage=round(100*evaluated/applicable) if applicable else None)

def identity(row):return (row['assetId'],row['baselineId'],row['rule'])

def policy(run,row):
    baseline=next((b for b in run['baselines'] if b['id']==row['baselineId']),{})
    rule=next((r for r in baseline.get('rules',[]) if r['id']==row['rule']),{})
    content=dict(version=row['version'],rule=rule,overridden=row.get('overridden',False))
    return hashlib.sha256(json.dumps(content,sort_keys=True).encode()).hexdigest()

def annotate(run,history):
    run['analysis']=summarize(run['rows'])
    previous=history[-1] if history else None
    oldrows={identity(r):r for r in previous['rows']} if previous else {}
    for row in run['rows']:
        old=oldrows.get(identity(row));kind='First observation' if not previous else 'New check'
        current_config=run['configs'].get(row['assetId'],{})
        old_config=previous['configs'].get(row['assetId'],{}) if previous else {}
        evidence_changed=bool(current_config) and current_config.get('hash')!=old_config.get('hash')
        if old:
            if policy(run,row)!=policy(previous,old):kind='Requirement changed'
            elif row.get('checkEvidence',{}).get('parser')!=old.get('checkEvidence',{}).get('parser'):kind='Analysis engine changed'
            elif old['status']=='Fail' and row['status']=='Pass':kind='Resolved'
            elif old['status']=='Pass' and row['status']=='Fail':
                earlier_failure=any(any(identity(r)==identity(row) and r['status']=='Fail' for r in h['rows']) for h in history[:-1])
                kind='Reopened' if earlier_failure else 'New failure'
            elif row['status']=='Fail' and old['status']=='Fail':kind='Recurring failure'
            elif row['status']!=old['status']:kind='Assessment status changed'
            elif row['observed']!=old['observed']:kind='Setting changed'
            else:kind='Unchanged'
        row['change']=dict(kind=kind,previousStatus=old['status'] if old else None,previousObserved=old['observed'] if old else None,evidenceChanged=evidence_changed,previousRun=previous['id'] if previous else None)
    run['analysis']['removedChecks']=[dict(asset=r['asset'],rule=r['rule'],baseline=r['baseline'],status=r['status']) for key,r in oldrows.items() if key not in {identity(row) for row in run['rows']}]
    return run
