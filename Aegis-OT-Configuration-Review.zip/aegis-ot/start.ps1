$ErrorActionPreference = 'Stop'
$auditPython = Get-Command python -ErrorAction SilentlyContinue
if ($auditPython) {
    & $auditPython.Source (Join-Path $PSScriptRoot 'server.py')
} else {
    $auditBundledPython = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
    if (Test-Path -LiteralPath $auditBundledPython) {
        & $auditBundledPython (Join-Path $PSScriptRoot 'server.py')
    } else {
        throw 'Install Python 3.10 or newer, install requirements.txt, then run python server.py.'
    }
}
